"""One-command launcher:  python run.py   (Windows: start.bat, Mac/Linux: ./start.sh)

1. Starts a free Cloudflare quick tunnel (downloads cloudflared.exe into ./bin on Windows if missing).
2. Uses the tunnel's https address as PUBLIC_BASE_URL automatically (overrides .env for this run).
3. Starts the bot + dashboard, then runs the preflight check and prints PASS/FAIL/SKIP.
Creates .env from .env.example on first run if missing; never overwrites an existing .env. If the tunnel cannot start, the dashboard still runs locally (no live meeting bot).
"""
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import urllib.request

PORT = int(os.environ.get("PORT", "8000"))
ROOT = os.path.dirname(os.path.abspath(__file__))
CF_URL = "https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe"


def find_cloudflared() -> str | None:
    exe = os.environ.get("CLOUDFLARED_PATH") or shutil.which("cloudflared")
    if exe:
        return exe
    local = os.path.join(ROOT, "bin", "cloudflared.exe")
    if os.path.exists(local):
        return local
    if sys.platform == "win32":
        try:
            os.makedirs(os.path.dirname(local), exist_ok=True)
            print("Downloading cloudflared (free tunnel tool, one time, ~40 MB)...")
            urllib.request.urlretrieve(CF_URL, local)
            return local
        except Exception as e:  # noqa: BLE001
            print(f"Could not download cloudflared: {e}")
    return None


def start_tunnel(exe: str):
    p = subprocess.Popen([exe, "tunnel", "--url", f"http://localhost:{PORT}", "--no-autoupdate"],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    url = None
    deadline = time.time() + 60
    for line in p.stdout:  # cloudflared prints continuously while starting
        m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", line)
        if m:
            url = m.group(0)
            break
        if time.time() > deadline:
            break
    threading.Thread(target=lambda: [None for _ in p.stdout], daemon=True).start()  # keep the pipe drained
    return p, url


def preflight_later(delay: int = 20):
    def go():
        time.sleep(delay)
        print("\n=== Preflight check ===")
        try:
            subprocess.run([sys.executable, "-m", "app.preflight"], cwd=ROOT, timeout=180)
        except Exception as e:  # noqa: BLE001
            print(f"preflight could not run: {e}")
        print("=======================\n")
    threading.Thread(target=go, daemon=True).start()


def main() -> None:
    os.chdir(ROOT)
    if not os.path.exists(".env"):
        if os.path.exists(".env.example"):
            shutil.copyfile(".env.example", ".env")
            print("Created .env from .env.example (demo defaults, no API keys). Edit .env later to add keys.")
        else:
            print("No .env found; continuing with built-in defaults.")
    tunnel = None
    exe = find_cloudflared()
    if exe:
        print("Starting free public tunnel...")
        tunnel, url = start_tunnel(exe)
        if url:
            os.environ["PUBLIC_BASE_URL"] = url
            print(f"Public address (Recall reaches the bot here): {url}")
        else:
            print("Tunnel did not give an address; continuing locally only.")
    else:
        print("cloudflared not available; continuing locally only (no live meeting bot).")
    print(f"Dashboard on this PC: http://localhost:{PORT}  (login: see DASHBOARD_USER / DASHBOARD_PASSWORD in .env)")
    preflight_later()
    import uvicorn  # imported late so PUBLIC_BASE_URL is already set when app.config loads
    try:
        uvicorn.run("app.main:app", host="0.0.0.0", port=PORT)
    finally:
        if tunnel:
            tunnel.terminate()


if __name__ == "__main__":
    main()
