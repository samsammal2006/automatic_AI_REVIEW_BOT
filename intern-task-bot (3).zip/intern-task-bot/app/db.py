import datetime as dt
import json
import os

from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, String, Table, Text, create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship, sessionmaker

from .config import settings


def utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc).replace(tzinfo=None)


class Base(DeclarativeBase):
    pass


meeting_interns = Table(
    "meeting_interns", Base.metadata,
    Column("meeting_id", ForeignKey("meetings.id", ondelete="CASCADE"), primary_key=True),
    Column("intern_id", ForeignKey("interns.id", ondelete="CASCADE"), primary_key=True),
)


class Intern(Base):
    __tablename__ = "interns"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(200), unique=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)


class Meeting(Base):
    __tablename__ = "meetings"
    id: Mapped[int] = mapped_column(primary_key=True)
    type: Mapped[str] = mapped_column(String(20))  # kickoff | review
    title: Mapped[str] = mapped_column(String(200))
    scheduled_at: Mapped[dt.datetime] = mapped_column(DateTime)
    duration: Mapped[int] = mapped_column(Integer, default=60)
    join_url: Mapped[str | None] = mapped_column(String(500), nullable=True)
    zoom_id: Mapped[str | None] = mapped_column(String(400), nullable=True)  # provider meeting id (Zoom id / Meet space / Teams id)
    bot_id: Mapped[str | None] = mapped_column(String(80), nullable=True)
    # scheduled|starting|live|ended|awaiting_approval|processed|failed|cancelled|no_show
    status: Mapped[str] = mapped_column(String(30), default="scheduled")
    summary: Mapped[str | None] = mapped_column(Text, nullable=True)
    state_json: Mapped[str] = mapped_column(Text, default="{}")
    parent_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    reminder_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    started_at: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    attendees: Mapped[list[Intern]] = relationship(secondary=meeting_interns, lazy="selectin")


class Task(Base):
    __tablename__ = "tasks"
    id: Mapped[int] = mapped_column(primary_key=True)
    intern_id: Mapped[int] = mapped_column(ForeignKey("interns.id"))
    meeting_id: Mapped[int | None] = mapped_column(Integer, nullable=True)         # kickoff where assigned
    review_meeting_id: Mapped[int | None] = mapped_column(Integer, nullable=True)  # next review
    title: Mapped[str] = mapped_column(String(300))
    description: Mapped[str] = mapped_column(Text, default="")
    deadline: Mapped[dt.datetime | None] = mapped_column(DateTime, nullable=True)
    status: Mapped[str] = mapped_column(String(20), default="assigned")  # assigned|partial|not_done|done|cancelled
    notes: Mapped[str] = mapped_column(Text, default="")
    reminded: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    intern: Mapped[Intern] = relationship(lazy="selectin")


class Review(Base):
    __tablename__ = "reviews"
    id: Mapped[int] = mapped_column(primary_key=True)
    task_id: Mapped[int] = mapped_column(ForeignKey("tasks.id"))
    meeting_id: Mapped[int] = mapped_column(Integer)
    outcome: Mapped[str] = mapped_column(String(20))
    notes: Mapped[str] = mapped_column(Text, default="")
    created_at: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)


class Utterance(Base):
    __tablename__ = "utterances"
    id: Mapped[int] = mapped_column(primary_key=True)
    meeting_id: Mapped[int] = mapped_column(Integer, index=True)
    speaker: Mapped[str] = mapped_column(String(120))
    text: Mapped[str] = mapped_column(Text)
    is_bot: Mapped[bool] = mapped_column(Boolean, default=False)
    dedupe_key: Mapped[str | None] = mapped_column(String(64), nullable=True, index=True)  # webhook retry safety
    ts: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)


class KV(Base):
    """Small key/value store (OAuth refresh tokens obtained through the dashboard)."""
    __tablename__ = "kv"
    key: Mapped[str] = mapped_column(String(80), primary_key=True)
    value: Mapped[str] = mapped_column(Text, default="")


class Log(Base):
    __tablename__ = "logs"
    id: Mapped[int] = mapped_column(primary_key=True)
    ts: Mapped[dt.datetime] = mapped_column(DateTime, default=utcnow)
    level: Mapped[str] = mapped_column(String(10), default="info")
    message: Mapped[str] = mapped_column(Text)


if settings.database_url.startswith("sqlite:///"):
    _p = settings.database_url.replace("sqlite:///", "", 1)
    if os.path.dirname(_p):
        os.makedirs(os.path.dirname(_p), exist_ok=True)
engine = create_engine(
    settings.database_url,
    connect_args={"check_same_thread": False} if settings.database_url.startswith("sqlite") else {},
)
SessionLocal = sessionmaker(engine, expire_on_commit=False)


def init_db():
    """Apply Alembic migrations (adopts pre-Alembic databases); fall back to create_all if Alembic is unavailable."""
    try:
        from alembic import command
        from alembic.config import Config
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        cfg = Config(os.path.join(root, "alembic.ini"))
        cfg.set_main_option("script_location", os.path.join(root, "migrations"))
        with engine.begin() as conn:
            cfg.attributes["connection"] = conn
            command.upgrade(cfg, "head")
    except Exception as e:  # pragma: no cover
        import logging
        logging.getLogger("internbot").warning("Alembic migration failed (%s); using create_all", e)
        Base.metadata.create_all(engine)


def kv_get(key: str, default: str = "") -> str:
    with SessionLocal() as s:
        row = s.get(KV, key)
        return row.value if row else default


def kv_set(key: str, value: str) -> None:
    with SessionLocal() as s:
        row = s.get(KV, key)
        if row:
            row.value = value
        else:
            s.add(KV(key=key, value=value))
        s.commit()


def jload(s: str | None) -> dict:
    try:
        return json.loads(s or "{}")
    except Exception:
        return {}
