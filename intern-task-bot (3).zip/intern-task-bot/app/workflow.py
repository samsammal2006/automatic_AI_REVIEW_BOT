"""Core bot logic: kickoff briefing, post-meeting planning, emails, review meetings, scheduler tick."""
import asyncio
import datetime as dt
import hashlib
import json
import logging
import re
from zoneinfo import ZoneInfo

from sqlalchemy import select

from .config import settings
from .db import Intern, Log, Meeting, Review, SessionLocal, Task, Utterance, jload, utcnow
from .services import llm, mailer, provider, recall, tts, zoom  # noqa: F401  (zoom kept for tests/monkeypatching)

logger = logging.getLogger("internbot")
TZ = ZoneInfo(settings.timezone)
OPEN = ("assigned", "partial", "not_done")


# ------------------------------------------------------------------ helpers
def add_log(msg: str, level: str = "info") -> None:
    getattr(logger, level if level in ("info", "warning", "error") else "info")(msg)
    with SessionLocal() as s:
        s.add(Log(level=level, message=msg[:2000]))
        s.commit()


def to_local(d: dt.datetime) -> dt.datetime:
    return d.replace(tzinfo=dt.timezone.utc).astimezone(TZ)


def fmt_dt(d: dt.datetime | None) -> str:
    return to_local(d).strftime("%a, %d %b %Y, %I:%M %p %Z") if d else "TBD"


def fmt_date(d: dt.datetime | None) -> str:
    return to_local(d).strftime("%a, %d %b %Y") if d else "TBD"


def local_to_utc(date: dt.date, hour: int = 0, minute: int = 0) -> dt.datetime:
    return dt.datetime(date.year, date.month, date.day, hour, minute, tzinfo=TZ).astimezone(dt.timezone.utc).replace(tzinfo=None)


def deadline_for(date: dt.date) -> dt.datetime:
    return local_to_utc(date, 23, 59)


def parse_date(v) -> dt.date | None:
    try:
        return dt.date.fromisoformat(str(v)[:10]) if v else None
    except Exception:
        return None


def today_local() -> dt.date:
    return to_local(utcnow()).date()


def get_state(mid: int) -> dict:
    with SessionLocal() as s:
        return jload(s.get(Meeting, mid).state_json)


def upd_state(mid: int, **kw) -> dict:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        st = jload(m.state_json)
        st.update(kw)
        m.state_json = json.dumps(st)
        s.commit()
        return st


def set_status(mid: int, status: str, **kw) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        m.status = status
        for k, v in kw.items():
            setattr(m, k, v)
        s.commit()


def task_dict(t: Task) -> dict:
    return {"id": t.id, "intern": t.intern.name, "title": t.title, "description": t.description,
            "deadline": fmt_date(t.deadline) if t.deadline else None, "status": t.status}


def mentor_cc() -> list[str]:
    return [settings.mentor_email] if settings.mentor_email else []


async def safe_mail(*a, **kw) -> bool:
    try:
        ok = await mailer.send(*a, **kw)
        if not ok:
            add_log("Email skipped: SMTP not configured", "warning")
        return ok
    except Exception as e:
        add_log(f"Email failed: {e}", "error")
        return False


# ------------------------------------------------------------------ runtime (per live meeting)
class RT:
    def __init__(self):
        self.speak_lock = asyncio.Lock()
        self.buf: list[str] = []
        self.debounce: asyncio.Task | None = None
        self.busy = False
        self.last_answer = 0.0
        self.running_intro = False


RUNTIME: dict[int, RT] = {}


def rt(mid: int) -> RT:
    return RUNTIME.setdefault(mid, RT())


def chunks(text: str, limit: int = 450) -> list[str]:
    parts, cur = [], ""
    for sent in re.split(r"(?<=[.!?])\s+", text.strip()):
        if len(cur) + len(sent) + 1 > limit and cur:
            parts.append(cur)
            cur = ""
        cur = f"{cur} {sent}".strip()
    if cur:
        parts.append(cur)
    return parts


async def speak(mid: int, bot_id: str, text: str) -> None:
    """Speak via TTS into the call; falls back to meeting chat."""
    r = rt(mid)
    with SessionLocal() as s:
        s.add(Utterance(meeting_id=mid, speaker=settings.bot_name, text=text, is_bot=True))
        s.commit()
    async with r.speak_lock:
        for part in chunks(text):
            audio = None
            if tts.enabled():
                try:
                    audio = await tts.synthesize(part)
                except Exception as e:
                    add_log(f"TTS failed, using chat: {e}", "warning")
            try:
                if audio:
                    await recall.output_audio(bot_id, audio)
                    await asyncio.sleep(len(part.split()) / 2.4 + 0.8)
                else:
                    await recall.send_chat(bot_id, part)
                    await asyncio.sleep(1.0)
            except Exception as e:
                add_log(f"Bot speak failed: {e}", "error")


# ------------------------------------------------------------------ creating meetings
async def create_meeting(type_: str, title: str, scheduled_at: dt.datetime, intern_ids: list[int],
                         join_url: str | None = None, duration: int = 60, parent_id: int | None = None,
                         notify: bool = True) -> int:
    zid = None
    if not join_url:
        join_url, zid = await provider.create_meeting(title, scheduled_at, duration)
    with SessionLocal() as s:
        m = Meeting(type=type_, title=title, scheduled_at=scheduled_at, join_url=join_url, zoom_id=zid,
                    duration=duration, parent_id=parent_id, status="scheduled")
        m.attendees = [s.get(Intern, i) for i in intern_ids if s.get(Intern, i)]
        s.add(m)
        s.commit()
        mid = m.id
    add_log(f"Meeting #{mid} '{title}' scheduled for {fmt_dt(scheduled_at)}")
    if notify:
        await send_invite(mid)
    return mid


async def send_invite(mid: int, reminder: bool = False, only_intern_id: int | None = None) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        att = [i for i in m.attendees if only_intern_id is None or i.id == only_intern_id]
    kind = "Review" if m.type == "review" else "Kickoff"
    pre = "Reminder: " if reminder else ""
    ics = mailer.make_ics(f"meeting-{mid}", m.title, m.scheduled_at, m.duration, m.join_url)
    for i in att:
        inner = (f"<p>Hi {i.name},</p><p>{'Your' if reminder else 'You are invited to the'} {kind.lower()} meeting "
                 f"<b>{m.title}</b> is on <b>{fmt_dt(m.scheduled_at)}</b>.</p>"
                 f'<p><a href="{m.join_url}">Join the meeting</a></p>'
                 "<p>An AI assistant will attend, explain/review tasks, and transcribe the meeting.</p>")
        await safe_mail(i.email, f"{pre}[{kind}] {m.title} - {fmt_dt(m.scheduled_at)}",
                        mailer.layout(f"{kind} meeting", inner),
                        f"Hi {i.name}, {m.title} is on {fmt_dt(m.scheduled_at)}. Join: {m.join_url}", ics=ics)


# ------------------------------------------------------------------ bot lifecycle
async def start_bot(mid: int) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        if m.status != "scheduled":
            return
        m.status = "starting"
        s.commit()
        url = m.join_url
    try:
        bot_id = await recall.create_bot(mid, url)
        set_status(mid, "live", bot_id=bot_id, started_at=utcnow())
        upd_state(mid, participants={}, ever_joined=False, briefed=False, finalized=False)
        add_log(f"Bot {bot_id} joining meeting #{mid}")
    except Exception as e:
        set_status(mid, "failed")
        add_log(f"Could not start bot for meeting #{mid}: {e}", "error")
        if settings.mentor_email:
            await safe_mail(settings.mentor_email, f"Bot failed to join meeting #{mid}",
                            mailer.layout("Bot failed to join", f"<p>{e}</p>"), f"Bot failed: {e}")


async def leave_and_finish(mid: int) -> None:
    with SessionLocal() as s:
        bot_id = s.get(Meeting, mid).bot_id
    if bot_id:
        try:
            await recall.leave(bot_id)
        except Exception:
            pass
    await finish(mid)


async def finish(mid: int) -> None:
    """Idempotent: runs post-meeting processing once."""
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        if m.status != "live" or jload(m.state_json).get("finishing"):
            return
    upd_state(mid, finishing=True)
    set_status(mid, "ended")
    await asyncio.sleep(2)
    try:
        with SessionLocal() as s:
            m = s.get(Meeting, mid)
            have = s.scalar(select(Utterance.id).where(Utterance.meeting_id == mid, Utterance.is_bot.is_(False)).limit(1))
            bot_id = m.bot_id
        if not have and bot_id:
            try:
                for sp, tx in await recall.fetch_transcript(await recall.get_bot(bot_id)):
                    with SessionLocal() as s:
                        s.add(Utterance(meeting_id=mid, speaker=sp, text=tx))
                        s.commit()
            except Exception as e:
                add_log(f"Transcript fallback failed: {e}", "warning")
        if m.type == "kickoff":
            await process_kickoff(mid)
        else:
            await process_review(mid)
    except Exception as e:
        set_status(mid, "failed")
        add_log(f"Post-meeting processing failed for #{mid}: {e}", "error")
    RUNTIME.pop(mid, None)


def transcript_text(mid: int) -> str:
    with SessionLocal() as s:
        rows = s.scalars(select(Utterance).where(Utterance.meeting_id == mid).order_by(Utterance.id)).all()
    return "\n".join(f"{u.speaker}: {u.text}" for u in rows)


# ------------------------------------------------------------------ webhook events
async def on_recall_event(mid: int, body: dict) -> None:
    ev = body.get("event", "")
    data = (body.get("data") or {}).get("data") or {}
    part = data.get("participant") or {}
    name = part.get("name") or "Unknown"
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        if not m or m.status != "live":
            return
    if name == settings.bot_name:
        return
    if ev == "participant_events.join":
        st = get_state(mid)
        ps = st.get("participants", {})
        ps[str(part.get("id"))] = name
        upd_state(mid, participants=ps, ever_joined=True, empty_since=None)
    elif ev == "participant_events.leave":
        st = get_state(mid)
        ps = st.get("participants", {})
        ps.pop(str(part.get("id")), None)
        upd_state(mid, participants=ps, empty_since=None if ps else utcnow().isoformat())
    elif ev == "transcript.data":
        words = data.get("words", [])
        text = " ".join(w.get("text", "") for w in words).strip()
        if text:
            first = ((words[0].get("start_timestamp") or {}).get("relative") if words else None)
            key = hashlib.sha1(f"{part.get('id')}|{first}|{text}".encode()).hexdigest()
            await handle_utterance(mid, name, text, key)


async def handle_utterance(mid: int, speaker: str, text: str, key: str | None = None) -> None:
    with SessionLocal() as s:
        if key and s.scalar(select(Utterance.id).where(Utterance.meeting_id == mid, Utterance.dedupe_key == key)):
            return  # Recall retried this webhook; already processed
        s.add(Utterance(meeting_id=mid, speaker=speaker, text=text, dedupe_key=key))
        m = s.get(Meeting, mid)
        mtype = m.type
        s.commit()
    st = get_state(mid)
    r = rt(mid)
    if mtype == "kickoff" and st.get("briefed") and llm.looks_like_question(text):
        now = asyncio.get_event_loop().time()
        if now - r.last_answer > 6:
            r.last_answer = now
            asyncio.create_task(answer_question(mid, speaker, text))
    elif mtype == "review" and st.get("awaiting") and not r.busy:
        cur = st.get("current_intern")
        if cur and not _speaker_ok(speaker, cur, st):
            return
        r.buf.append(text)
        if r.debounce:
            r.debounce.cancel()
        r.debounce = asyncio.create_task(_debounced(mid))


def _speaker_ok(speaker: str, intern_name: str, st: dict) -> bool:
    """Accept the answer if the speaker matches the intern, or if no participant name matches any intern."""
    sp, iname = speaker.lower(), intern_name.lower()
    first = iname.split()[0]
    if first in sp or sp in iname:
        return True
    with SessionLocal() as s:
        others = [i.name.split()[0].lower() for i in s.scalars(select(Intern)).all() if i.name.lower() != iname]
    return not any(o in sp for o in others)


async def answer_question(mid: int, speaker: str, question: str) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        bot_id = m.bot_id
        tasks = s.scalars(select(Task).where(Task.meeting_id == mid)).all()
        ctx = json.dumps([task_dict(t) for t in tasks])
    recent = "\n".join(transcript_text(mid).splitlines()[-8:])
    ans = await llm.answer(settings.bot_name, question, speaker, f"Tasks: {ctx}\nRecent conversation:\n{recent}")
    await speak(mid, bot_id, ans)


# ------------------------------------------------------------------ kickoff
async def run_kickoff(mid: int) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        bot_id, title = m.bot_id, m.title
        tasks = [task_dict(t) for t in s.scalars(select(Task).where(Task.meeting_id == mid)).all()]
    paras = await llm.briefing(settings.bot_name, title, tasks)
    for p in paras:
        await speak(mid, bot_id, p)
    await speak(mid, bot_id, "I'll set deadlines and email everyone the summary and review date after this meeting.")
    upd_state(mid, briefed=True)


def default_review_dt(tasks: list[Task]) -> dt.datetime:
    latest = max((t.deadline for t in tasks if t.deadline), default=None)
    base = (to_local(latest).date() if latest else today_local() + dt.timedelta(days=settings.default_deadline_days))
    cand = local_to_utc(base + dt.timedelta(days=1), settings.review_hour)
    return max(cand, utcnow() + dt.timedelta(hours=12))


async def process_kickoff(mid: int) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        tasks = s.scalars(select(Task).where(Task.meeting_id == mid)).all()
        interns = list(m.attendees)
        sched = m.scheduled_at
    tdicts = [{"id": t.id, "intern": t.intern.name, "title": t.title, "deadline": fmt_date(t.deadline) if t.deadline else None} for t in tasks]
    plan = await llm.extract_plan(transcript_text(mid), tdicts,
                                  [{"name": i.name, "email": i.email} for i in interns], today_local().isoformat())
    by_id = {t["id"]: t for t in plan["tasks"] if isinstance(t, dict) and "id" in t}
    default_dl = deadline_for(to_local(sched).date() + dt.timedelta(days=settings.default_deadline_days))
    with SessionLocal() as s:
        for t in s.scalars(select(Task).where(Task.meeting_id == mid)).all():
            p = by_id.get(t.id, {})
            d = parse_date(p.get("deadline"))
            if d:
                t.deadline = deadline_for(d)
            elif not t.deadline:
                t.deadline = default_dl
            if p.get("notes"):
                t.notes = (t.notes + "\n" if t.notes else "") + p["notes"]
        emails = {i.email.lower(): i for i in interns}
        for nt in plan["new_tasks"]:
            intern = emails.get(str(nt.get("intern_email", "")).lower())
            if intern and nt.get("title"):
                d = parse_date(nt.get("deadline"))
                s.add(Task(intern_id=intern.id, meeting_id=mid, title=nt["title"][:300],
                           description=nt.get("description") or "", deadline=deadline_for(d) if d else default_dl))
        s.commit()
    rd = parse_date(plan.get("review_date"))
    upd_state(mid, review_date=rd.isoformat() if rd else None)
    if settings.require_approval:
        set_status(mid, "awaiting_approval")
        add_log(f"Kickoff #{mid} processed; awaiting mentor approval in dashboard")
        if settings.mentor_email:
            await safe_mail(settings.mentor_email, f"Approve tasks for '{m.title}'",
                            mailer.layout("Approval needed", "<p>Review deadlines in the dashboard, then approve to send emails.</p>"),
                            "Approval needed in dashboard.")
        return
    await dispatch_kickoff(mid)


async def dispatch_kickoff(mid: int) -> None:
    """Create the review meeting and email every intern their tasks, deadlines and review date."""
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        tasks = s.scalars(select(Task).where(Task.meeting_id == mid, Task.status.in_(OPEN))).all()
        title = m.title
    if not tasks:
        set_status(mid, "processed")
        return
    rd = parse_date(get_state(mid).get("review_date"))
    review_at = local_to_utc(rd, settings.review_hour) if rd else default_review_dt(tasks)
    if review_at < utcnow() + dt.timedelta(hours=1):
        review_at = utcnow() + dt.timedelta(days=1)
    review_mid = await schedule_review(tasks, f"Review: {title}", review_at, parent=mid)
    await email_assignments(mid, review_mid)
    set_status(mid, "processed")
    upd_state(mid, review_meeting_id=review_mid)
    add_log(f"Kickoff #{mid} done: review meeting #{review_mid} set for {fmt_dt(review_at)}")


async def schedule_review(tasks: list[Task], title: str, when: dt.datetime, parent: int | None) -> int:
    ids = sorted({t.intern_id for t in tasks})
    link = None
    if not provider.can_create():
        # MEETING_PROVIDER=manual cannot mint links: reuse the previous meeting's link (editable in the dashboard).
        with SessionLocal() as s:
            link = s.get(Meeting, parent).join_url if parent else None
        if link:
            add_log(f"Manual mode: review for '{title}' reuses the previous meeting link; edit it in the dashboard if needed.")
    rmid = await create_meeting("review", title, when, ids, join_url=link, parent_id=parent, notify=False)
    with SessionLocal() as s:
        for t in tasks:
            s.get(Task, t.id).review_meeting_id = rmid
        s.commit()
    return rmid


async def email_assignments(kick_mid: int, review_mid: int) -> None:
    with SessionLocal() as s:
        rm = s.get(Meeting, review_mid)
        tasks = s.scalars(select(Task).where(Task.meeting_id == kick_mid, Task.status.in_(OPEN))).all()
        kick = s.get(Meeting, kick_mid)
    by: dict[int, list[Task]] = {}
    for t in tasks:
        by.setdefault(t.intern_id, []).append(t)
    ics = mailer.make_ics(f"meeting-{review_mid}", rm.title, rm.scheduled_at, rm.duration, rm.join_url)
    for ts in by.values():
        i = ts[0].intern
        rows = [task_dict(t) for t in ts]
        inner = (f"<p>Hi {i.name},</p><p>Thanks for attending <b>{kick.title}</b>. Here are your tasks:</p>{mailer.tasks_table(rows)}"
                 f"<p><b>Review meeting:</b> {fmt_dt(rm.scheduled_at)}<br><a href=\"{rm.join_url}\">Join link</a></p>"
                 "<p>Please complete the tasks before their deadlines. The bot will ask for a status update in the review.</p>")
        lines = "\n".join(f"- {r['title']} (due {r['deadline']})" for r in rows)
        await safe_mail(i.email, f"Your tasks, deadlines & review date - {kick.title}",
                        mailer.layout("Your tasks and deadlines", inner),
                        f"Hi {i.name},\n{lines}\nReview: {fmt_dt(rm.scheduled_at)} {rm.join_url}", ics=ics, cc=mentor_cc())


# ------------------------------------------------------------------ review
async def run_review_intro(mid: int) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        bot_id = m.bot_id
        tasks = s.scalars(select(Task).where(Task.review_meeting_id == mid, Task.status.in_(OPEN))
                          .order_by(Task.intern_id, Task.id)).all()
    queue = [t.id for t in tasks]
    upd_state(mid, queue=queue, idx=0, awaiting=False, briefed=True)
    await speak(mid, bot_id, f"Hello everyone, I'm {settings.bot_name}. This is the task review. "
                             "I'll ask each of you for a short status update on your tasks.")
    await ask_next(mid)


async def ask_next(mid: int) -> None:
    st = get_state(mid)
    with SessionLocal() as s:
        bot_id = s.get(Meeting, mid).bot_id
    if st.get("idx", 0) >= len(st.get("queue", [])):
        return await review_wrapup(mid)
    with SessionLocal() as s:
        t = s.get(Task, st["queue"][st["idx"]])
        name, title, dl = t.intern.name, t.title, fmt_date(t.deadline)
    rt(mid).buf.clear()
    rt(mid).busy = False
    upd_state(mid, awaiting=False, current_intern=name)
    await speak(mid, bot_id, f"{name}, let's talk about {title}. It was due {dl}. How is it going, is it complete?")
    upd_state(mid, awaiting=True, asked_at=utcnow().isoformat(), attempts=0)


async def _debounced(mid: int) -> None:
    await asyncio.sleep(4.5)
    r = rt(mid)
    reply = " ".join(r.buf).strip()
    if not reply or r.busy:
        return
    r.busy = True
    try:
        st = get_state(mid)
        task_id = st["queue"][st["idx"]]
        with SessionLocal() as s:
            t = s.get(Task, task_id)
            td = task_dict(t)
            bot_id = s.get(Meeting, mid).bot_id
        res = await llm.classify_status(td, reply, today_local().isoformat())
        if res["status"] == "unclear" and st.get("attempts", 0) == 0:
            r.buf.clear()
            upd_state(mid, attempts=1, asked_at=utcnow().isoformat())
            await speak(mid, bot_id, "Sorry, I didn't catch the progress. Is the task done, partly done, or not started?")
            return
        if res["status"] == "unclear":
            res["status"] = "not_done"
        await apply_answer(mid, task_id, res["status"], res.get("notes") or reply, parse_date(res.get("new_deadline")))
    except Exception as e:
        add_log(f"Review answer handling failed for #{mid}: {e}", "error")
    finally:
        r.busy = False


async def apply_answer(mid: int, task_id: int, status: str, notes: str, new_deadline: dt.date | None) -> None:
    st = get_state(mid)
    if st.get("queue") and st.get("idx", 0) < len(st["queue"]) and st["queue"][st["idx"]] != task_id:
        return  # stale/duplicate answer for a task that was already handled
    with SessionLocal() as s:
        t = s.get(Task, task_id)
        t.status = status
        t.notes = (t.notes + "\n" if t.notes else "") + f"[{fmt_date(utcnow())}] {notes}"
        if status != "done":
            nd = new_deadline if (new_deadline and new_deadline > today_local()) else today_local() + dt.timedelta(days=settings.followup_days)
            t.deadline = deadline_for(nd)
            t.reminded = False
        s.add(Review(task_id=task_id, meeting_id=mid, outcome=status, notes=notes))
        bot_id = s.get(Meeting, mid).bot_id
        dl = fmt_date(t.deadline)
        s.commit()
    upd_state(mid, idx=st["idx"] + 1, awaiting=False)
    msg = ("Great work, I've marked that as complete." if status == "done"
           else f"Thanks, I've noted that as {status.replace('_', ' ')} and set a new deadline of {dl}.")
    await speak(mid, bot_id, msg)
    await ask_next(mid)


async def review_wrapup(mid: int) -> None:
    upd_state(mid, awaiting=False)
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        bot_id, title = m.bot_id, m.title
        tasks = s.scalars(select(Task).where(Task.review_meeting_id == mid)).all()
        pending = [t for t in tasks if t.status in OPEN]
    next_mid = None
    if pending:
        when = default_review_dt(pending)
        next_mid = await schedule_review(pending, title if title.startswith("Review") else f"Review: {title}", when, parent=mid)
        upd_state(mid, next_review_meeting_id=next_mid)
        await speak(mid, bot_id, f"Some tasks are still open, so I've scheduled the next review for {fmt_dt(when)}. "
                                 "You'll receive an email with the details. Thanks everyone!")
    else:
        await speak(mid, bot_id, "All tasks are complete. Fantastic work, everyone. Thanks for joining!")
    await leave_and_finish(mid)


async def process_review(mid: int) -> None:
    st = get_state(mid)
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        revs = {r.task_id: r for r in s.scalars(select(Review).where(Review.meeting_id == mid)).all()}
        ids = set(revs) | {t.id for t in s.scalars(select(Task).where(Task.review_meeting_id == mid)).all()}
        tasks = s.scalars(select(Task).where(Task.id.in_(ids))).all() if ids else []
    # tasks belonging to this review but never asked (e.g. bot left early): carry them forward
    next_mid = st.get("next_review_meeting_id")
    unasked = [t for t in tasks if t.id not in revs and t.status in OPEN]
    if unasked and not next_mid:
        when = default_review_dt(unasked)
        next_mid = await schedule_review(unasked, m.title, when, parent=mid)
        upd_state(mid, next_review_meeting_id=next_mid)
    lines = [f"{t.intern.name} - {t.title}: {revs[t.id].outcome if t.id in revs else 'not reviewed'}"
             + (f" ({revs[t.id].notes})" if t.id in revs else "") for t in tasks]
    summary = await llm.summarize_review(lines)
    with SessionLocal() as s:
        s.get(Meeting, mid).summary = summary
        s.commit()
    nxt = None
    if next_mid:
        with SessionLocal() as s:
            nxt = s.get(Meeting, next_mid)
    by: dict[int, list[Task]] = {}
    for t in tasks:
        by.setdefault(t.intern_id, []).append(t)
    ics = mailer.make_ics(f"meeting-{nxt.id}", nxt.title, nxt.scheduled_at, nxt.duration, nxt.join_url) if nxt else None
    with SessionLocal() as s:
        fresh = {t.id: s.get(Task, t.id) for t in tasks}
    for ts in by.values():
        i = ts[0].intern
        rows = [task_dict(fresh[t.id]) for t in ts]
        extra = (f"<p><b>Next review:</b> {fmt_dt(nxt.scheduled_at)}<br><a href=\"{nxt.join_url}\">Join link</a></p>"
                 if nxt and any(fresh[t.id].status in OPEN for t in ts) else "<p>All your tasks are complete. Great job!</p>")
        await safe_mail(i.email, f"Review results - {m.title}",
                        mailer.layout("Review results", f"<p>Hi {i.name},</p>{mailer.tasks_table(rows)}{extra}"),
                        f"Hi {i.name}, review results for {m.title}.", ics=ics if extra.startswith("<p><b>Next") else None,
                        cc=mentor_cc())
    if settings.mentor_email:
        await safe_mail(settings.mentor_email, f"Review summary - {m.title}",
                        mailer.layout("Review summary", f"<pre style='white-space:pre-wrap'>{summary}</pre>"), summary)
    set_status(mid, "processed")
    add_log(f"Review #{mid} processed" + (f"; next review #{next_mid}" if next_mid else "; all tasks complete"))


# ------------------------------------------------------------------ no-show
async def handle_no_show(mid: int) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        att = list(m.attendees)
        title, mtype = m.title, m.type
        tasks = s.scalars(select(Task).where((Task.meeting_id == mid) | (Task.review_meeting_id == mid))).all()
    with SessionLocal() as s:
        bot_id = s.get(Meeting, mid).bot_id
    if bot_id:
        try:
            await recall.leave(bot_id)
        except Exception:
            pass
    set_status(mid, "no_show")
    when = local_to_utc(today_local() + dt.timedelta(days=1), settings.review_hour)
    try:
        new_mid = await create_meeting(mtype, title, when, [i.id for i in att], parent_id=mid)
        with SessionLocal() as s:
            for t in tasks:
                if mtype == "kickoff":
                    t.meeting_id = new_mid
                else:
                    t.review_meeting_id = new_mid
            s.commit()
        add_log(f"No-show for #{mid}; rescheduled as #{new_mid} on {fmt_dt(when)}", "warning")
    except Exception as e:
        add_log(f"No-show reschedule failed for #{mid}: {e}", "error")


# ------------------------------------------------------------------ restart recovery
async def recover() -> None:
    """Called once at startup: repairs meetings that were mid-flight when the process stopped."""
    with SessionLocal() as s:
        rows = [(m.id, m.status, m.bot_id, m.type) for m in s.scalars(
            select(Meeting).where(Meeting.status.in_(("starting", "live", "ended")))).all()]
    for mid, status, bot_id, mtype in rows:
        st = get_state(mid)
        if status == "starting":
            # crashed between 'starting' and bot creation; bot_id missing -> retry from scratch
            set_status(mid, "live" if bot_id else "scheduled")
            add_log(f"Recovered meeting #{mid} from 'starting'", "warning")
        elif status == "ended":
            upd_state(mid, finishing=False)
            set_status(mid, "live")
            add_log(f"Recovered meeting #{mid}: re-running post-meeting processing", "warning")
            asyncio.create_task(finish(mid))
        elif status == "live":
            upd_state(mid, finishing=False)
            if st.get("intro_started") and not st.get("briefed"):
                if mtype == "kickoff":
                    upd_state(mid, briefed=True)  # cannot resume mid-briefing; Q&A and processing continue
                else:
                    upd_state(mid, intro_started=False)  # review restarts its intro/queue cleanly
            if mtype == "review" and st.get("awaiting"):
                upd_state(mid, asked_at=utcnow().isoformat(), attempts=0)  # re-arm silence timer
            add_log(f"Recovered live meeting #{mid}", "warning")


# ------------------------------------------------------------------ reschedule
async def reschedule_meeting(mid: int, when: dt.datetime | None = None, title: str | None = None,
                             duration: int | None = None, join_url: str | None = None, notify: bool = True) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        if m.status != "scheduled":
            raise ValueError(f"Only scheduled meetings can be edited (this one is {m.status})")
        if when:
            m.scheduled_at = when
            m.reminder_sent = False
        if title:
            m.title = title
        if duration:
            m.duration = duration
        if join_url:
            m.join_url = join_url
        zid, t, w, d = m.zoom_id, m.title, m.scheduled_at, m.duration
        s.commit()
    if zid:
        try:
            await provider.update_meeting(zid, t, w, d)
        except Exception as e:
            add_log(f"{settings.meeting_provider} update failed for #{mid}: {e}", "error")
    add_log(f"Meeting #{mid} updated; now {fmt_dt(w)}")
    if notify:
        await send_invite(mid)


# ------------------------------------------------------------------ Recall bot status webhook
async def on_bot_status(bot_id: str, code: str, sub_code: str | None = None) -> None:
    """Instant reaction to Recall status-change webhooks (polling in check_live remains the safety net)."""
    with SessionLocal() as s:
        m = s.scalars(select(Meeting).where(Meeting.bot_id == bot_id)).first()
        mid, status = (m.id, m.status) if m else (None, None)
    if mid is None:
        return
    if code in ("call_ended", "done") and status == "live":
        await finish(mid)
    elif code == "fatal" and status == "live":
        set_status(mid, "failed")
        add_log(f"Bot fatal error in meeting #{mid}: {sub_code}", "error")
    elif code == "recording_permission_denied" and status == "live" and not get_state(mid).get("rec_warned"):
        upd_state(mid, rec_warned=True)
        add_log(f"Meeting #{mid}: recording permission denied ({sub_code}).", "error")
        try:
            await recall.send_chat(bot_id, "I need recording permission from the host to hear this meeting. "
                                           "Host: please approve the recording request.")
        except Exception:
            pass


# ------------------------------------------------------------------ scheduler tick
async def check_live(mid: int) -> None:
    with SessionLocal() as s:
        m = s.get(Meeting, mid)
        bot_id, mtype, sched, started = m.bot_id, m.type, m.scheduled_at, m.started_at
    st = get_state(mid)
    now = utcnow()
    bot_obj: dict = {}
    try:
        bot_obj = await recall.get_bot(bot_id)
        code = recall.status_code(bot_obj)
    except Exception as e:
        add_log(f"Bot status check failed #{mid}: {e}", "warning")
        code = None
    if code in ("call_ended", "done"):
        return await finish(mid)
    if code == "fatal":
        set_status(mid, "failed")
        return add_log(f"Bot fatal error in meeting #{mid}: {recall.sub_code(bot_obj, 'fatal')}", "error")
    if "recording_permission_denied" in recall.status_codes(bot_obj) and not st.get("rec_warned"):
        upd_state(mid, rec_warned=True)
        why = recall.sub_code(bot_obj, "recording_permission_denied") or "unknown"
        add_log(f"Meeting #{mid}: Zoom recording permission denied ({why}). The bot cannot hear the meeting until the "
                "host approves recording (or ZOOM_JOIN_TOKEN_URL is configured).", "error")
        try:
            await recall.send_chat(bot_id, "I need recording permission from the host to hear this meeting. "
                                           "Host: please approve the recording request.")
        except Exception:
            pass
    if started and now - started > dt.timedelta(minutes=settings.max_meeting_minutes):
        add_log(f"Meeting #{mid} exceeded max duration; leaving")
        return await leave_and_finish(mid)
    r = rt(mid)
    joined = bool(st.get("ever_joined"))
    if not st.get("briefed") and not r.running_intro:
        if joined and now >= sched and not st.get("intro_started"):
            r.running_intro = True
            upd_state(mid, intro_started=True)
            asyncio.create_task(run_kickoff(mid) if mtype == "kickoff" else run_review_intro(mid))
        elif not joined and now >= sched + dt.timedelta(minutes=10):
            return await handle_no_show(mid)
    if st.get("briefed") and joined and not st.get("participants"):
        es = st.get("empty_since")
        if es and now - dt.datetime.fromisoformat(es) > dt.timedelta(seconds=60):
            return await leave_and_finish(mid)
    if mtype == "review" and st.get("awaiting") and not r.busy and st.get("asked_at"):
        if now - dt.datetime.fromisoformat(st["asked_at"]) > dt.timedelta(seconds=80) and not r.buf:
            if st.get("attempts", 0) == 0:
                upd_state(mid, attempts=1, asked_at=now.isoformat())
                asyncio.create_task(speak(mid, bot_id, "Are you there? Could you give me a quick status update on this task?"))
            else:
                upd_state(mid, awaiting=False)
                r.busy = True
                task_id = st["queue"][st["idx"]]
                asyncio.create_task(apply_answer(mid, task_id, "not_done", "No response during the review.", None))


async def send_reminders() -> None:
    now = utcnow()
    with SessionLocal() as s:
        for m in s.scalars(select(Meeting).where(Meeting.status == "scheduled", Meeting.reminder_sent.is_(False))).all():
            if now < m.scheduled_at <= now + dt.timedelta(hours=24):
                m.reminder_sent = True
                s.commit()
                await send_invite(m.id, reminder=True)
        for t in s.scalars(select(Task).where(Task.status.in_(OPEN), Task.reminded.is_(False), Task.deadline.is_not(None))).all():
            if now < t.deadline <= now + dt.timedelta(hours=24):
                t.reminded = True
                s.commit()
                await safe_mail(t.intern.email, f"Reminder: '{t.title}' due {fmt_date(t.deadline)}",
                                mailer.layout("Task deadline tomorrow", f"<p>Hi {t.intern.name}, your task <b>{t.title}</b> is due {fmt_date(t.deadline)}.</p>"),
                                f"Reminder: {t.title} due {fmt_date(t.deadline)}")


_tick_lock = asyncio.Lock()


async def tick() -> None:
    if _tick_lock.locked():
        return
    async with _tick_lock:
        try:
            now = utcnow()
            with SessionLocal() as s:
                due = [m.id for m in s.scalars(select(Meeting).where(Meeting.status == "scheduled")).all()
                       if m.scheduled_at - dt.timedelta(minutes=settings.bot_lead_minutes) <= now < m.scheduled_at + dt.timedelta(hours=3)]
                live = [m.id for m in s.scalars(select(Meeting).where(Meeting.status == "live")).all()]
                missed = [m.id for m in s.scalars(select(Meeting).where(Meeting.status == "scheduled")).all()
                          if m.scheduled_at + dt.timedelta(hours=3) <= now]
            for mid in due:
                await start_bot(mid)
            for mid in live:
                await check_live(mid)
            for mid in missed:
                set_status(mid, "no_show")
            await send_reminders()
        except Exception as e:
            add_log(f"Tick error: {e}", "error")


async def scheduler_loop() -> None:
    while True:
        await tick()
        await asyncio.sleep(20)
