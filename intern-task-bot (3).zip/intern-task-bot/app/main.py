import asyncio
import base64
import csv
import datetime as dt
import hashlib
import hmac
import io
import json
import secrets
import urllib.parse
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import APIRouter, Depends, FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, PlainTextResponse, RedirectResponse, Response
from pydantic import BaseModel
from sqlalchemy import func, select

from . import workflow as wf
from .ratelimit import LoginLimiter
from .config import settings
from .db import Intern, Log, Meeting, Review, SessionLocal, Task, Utterance, init_db, kv_set, utcnow
from .services import http as httpx_retry, llm, mailer, meet, provider, recall, tts, zoom


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    await wf.recover()
    task = asyncio.create_task(wf.scheduler_loop())
    wf.add_log("Bot server started")
    yield
    task.cancel()


app = FastAPI(title="Intern Task Bot", lifespan=lifespan)
COOKIE = "itb_session"
limiter = LoginLimiter(5, 900)


def _client_ip(request: Request) -> str:
    xff = request.headers.get("x-forwarded-for", "")
    return xff.split(",")[0].strip() or (request.client.host if request.client else "?")
SESSION_HOURS = 12


def _secret() -> bytes:
    return (settings.session_secret or settings.webhook_secret).encode()


def make_session(user: str) -> str:
    exp = int((utcnow() + dt.timedelta(hours=SESSION_HOURS)).timestamp())
    payload = base64.urlsafe_b64encode(f"{user}|{exp}".encode()).decode()
    sig = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
    return f"{payload}.{sig}"


def make_state(purpose: str) -> str:
    """Signed, short-lived OAuth `state` (separate key and format from login cookies, so it can never act as a session)."""
    payload = base64.urlsafe_b64encode(f"{purpose}|{int((utcnow() + dt.timedelta(minutes=15)).timestamp())}".encode()).decode()
    return payload + "." + hmac.new(_secret() + b"|oauth-state", payload.encode(), hashlib.sha256).hexdigest()


def valid_state(tok: str | None, purpose: str) -> bool:
    try:
        payload, sig = (tok or "").rsplit(".", 1)
        if not hmac.compare_digest(sig, hmac.new(_secret() + b"|oauth-state", payload.encode(), hashlib.sha256).hexdigest()):
            return False
        p, exp = base64.urlsafe_b64decode(payload.encode()).decode().split("|")
        return p == purpose and int(exp) > utcnow().timestamp()
    except Exception:
        return False


def valid_session(tok: str | None) -> bool:
    try:
        payload, sig = (tok or "").rsplit(".", 1)
        good = hmac.new(_secret(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            return False
        user, exp = base64.urlsafe_b64decode(payload.encode()).decode().split("|")
        return user == settings.dashboard_user and int(exp) > utcnow().timestamp()
    except Exception:
        return False


def _basic_ok(request: Request) -> bool:
    h = request.headers.get("authorization", "")
    if not h.lower().startswith("basic "):
        return False
    try:
        u, _, p = base64.b64decode(h[6:]).decode().partition(":")
    except Exception:
        return False
    return secrets.compare_digest(u, settings.dashboard_user) and secrets.compare_digest(p, settings.dashboard_password)


def auth(request: Request):
    """Cookie session (dashboard login page) or HTTP Basic (scripts/curl)."""
    if valid_session(request.cookies.get(COOKIE)) or _basic_ok(request):
        return
    raise HTTPException(401, "Unauthorized")


LOGIN_HTML = """<!DOCTYPE html><html><head><meta charset=utf-8><meta name=viewport content="width=device-width,initial-scale=1">
<title>Sign in - Intern Task Bot</title><style>
body{margin:0;min-height:100vh;display:grid;place-items:center;font:15px system-ui,sans-serif;background:#f6f7fb;color:#1f2937}
@media(prefers-color-scheme:dark){body{background:#0f1117;color:#e5e7eb}form{background:#181b24!important;border-color:#2a2f3a!important}input{background:#0f1117;color:#e5e7eb;border-color:#2a2f3a!important}}
form{background:#fff;border:1px solid #e5e7eb;border-radius:14px;padding:28px;width:320px}h2{margin:0 0 16px}
input{width:100%;box-sizing:border-box;padding:10px;margin:6px 0 14px;border:1px solid #e5e7eb;border-radius:8px;font-size:15px}
button{width:100%;padding:11px;border:0;border-radius:8px;background:#4f46e5;color:#fff;font-size:15px;cursor:pointer}.e{color:#dc2626;margin-bottom:10px}
</style></head><body><form method=post action=/login><h2>Intern Task Bot</h2>__ERR__
<label>Username<input name=username autocomplete=username autofocus></label>
<label>Password<input name=password type=password autocomplete=current-password></label>
<button>Sign in</button></form></body></html>"""


api = APIRouter(prefix="/api", dependencies=[Depends(auth)])


def iso(d: dt.datetime | None):
    return d.isoformat() + "Z" if d else None


def parse_dt(v: str) -> dt.datetime:
    d = dt.datetime.fromisoformat(v.replace("Z", "+00:00"))
    return d.astimezone(dt.timezone.utc).replace(tzinfo=None) if d.tzinfo else d


def meeting_out(m: Meeting) -> dict:
    return {"id": m.id, "type": m.type, "title": m.title, "scheduled_at": iso(m.scheduled_at), "duration": m.duration,
            "join_url": m.join_url, "status": m.status, "summary": m.summary, "parent_id": m.parent_id,
            "attendees": [{"id": i.id, "name": i.name} for i in m.attendees]}


def task_out(t: Task, titles: dict | None = None) -> dict:
    return {"id": t.id, "intern_id": t.intern_id, "intern": t.intern.name, "title": t.title,
            "description": t.description, "deadline": iso(t.deadline), "status": t.status, "notes": t.notes,
            "meeting_id": t.meeting_id, "review_meeting_id": t.review_meeting_id}


# ---------------- schemas
class InternIn(BaseModel):
    name: str
    email: str


class TaskIn(BaseModel):
    intern_id: int
    title: str
    description: str = ""
    deadline: str | None = None  # YYYY-MM-DD


class TaskPatch(BaseModel):
    title: str | None = None
    description: str | None = None
    deadline: str | None = None
    status: str | None = None
    notes: str | None = None
    intern_id: int | None = None


class MeetingIn(BaseModel):
    type: str = "kickoff"
    title: str
    scheduled_at: str
    duration: int = 60
    intern_ids: list[int] = []
    join_url: str | None = None
    tasks: list[TaskIn] = []
    task_ids: list[int] = []  # for manual review meetings


# ---------------- interns
@api.get("/interns")
def interns():
    with SessionLocal() as s:
        return [{"id": i.id, "name": i.name, "email": i.email} for i in s.scalars(select(Intern).where(Intern.active)).all()]


@api.post("/interns")
def add_intern(b: InternIn):
    with SessionLocal() as s:
        if s.scalar(select(Intern).where(func.lower(Intern.email) == b.email.lower())):
            raise HTTPException(409, "Email already exists")
        i = Intern(name=b.name.strip(), email=b.email.strip())
        s.add(i)
        s.commit()
        return {"id": i.id}


@api.put("/interns/{iid}")
def edit_intern(iid: int, b: InternIn):
    with SessionLocal() as s:
        i = s.get(Intern, iid) or (_ for _ in ()).throw(HTTPException(404))
        i.name, i.email = b.name.strip(), b.email.strip()
        s.commit()
    return {"ok": True}


@api.delete("/interns/{iid}")
def del_intern(iid: int):
    with SessionLocal() as s:
        i = s.get(Intern, iid) or (_ for _ in ()).throw(HTTPException(404))
        i.active = False
        s.commit()
    return {"ok": True}


# ---------------- meetings
@api.get("/meetings")
def meetings():
    with SessionLocal() as s:
        return [meeting_out(m) for m in s.scalars(select(Meeting).order_by(Meeting.scheduled_at.desc())).all()]


@api.post("/meetings")
async def new_meeting(b: MeetingIn):
    if b.type not in ("kickoff", "review"):
        raise HTTPException(400, "type must be kickoff or review")
    when = parse_dt(b.scheduled_at)
    ids = set(b.intern_ids) | {t.intern_id for t in b.tasks}
    with SessionLocal() as s:
        if b.task_ids:
            ids |= {t.intern_id for t in s.scalars(select(Task).where(Task.id.in_(b.task_ids))).all()}
    if not ids:
        raise HTTPException(400, "Select at least one intern")
    try:
        mid = await wf.create_meeting(b.type, b.title, when, sorted(ids), b.join_url or None, b.duration)
    except Exception as e:
        raise HTTPException(400, f"Could not create meeting: {e}")
    with SessionLocal() as s:
        for t in b.tasks:
            d = wf.parse_date(t.deadline)
            s.add(Task(intern_id=t.intern_id, title=t.title, description=t.description,
                       deadline=wf.deadline_for(d) if d else None,
                       meeting_id=mid if b.type == "kickoff" else None,
                       review_meeting_id=mid if b.type == "review" else None))
        for tid in b.task_ids:
            if (t := s.get(Task, tid)):
                t.review_meeting_id = mid
        s.commit()
    return {"id": mid}


@api.get("/meetings/{mid}")
def meeting_detail(mid: int):
    with SessionLocal() as s:
        m = s.get(Meeting, mid) or (_ for _ in ()).throw(HTTPException(404))
        tasks = s.scalars(select(Task).where((Task.meeting_id == mid) | (Task.review_meeting_id == mid))).all()
        utt = s.scalars(select(Utterance).where(Utterance.meeting_id == mid).order_by(Utterance.id).limit(500)).all()
        revs = s.scalars(select(Review).where(Review.meeting_id == mid)).all()
        return {**meeting_out(m), "tasks": [task_out(t) for t in tasks],
                "transcript": [{"speaker": u.speaker, "text": u.text, "bot": u.is_bot, "ts": iso(u.ts)} for u in utt],
                "reviews": [{"task_id": r.task_id, "outcome": r.outcome, "notes": r.notes} for r in revs]}


@api.post("/meetings/{mid}/start")
async def force_start(mid: int):
    with SessionLocal() as s:
        m = s.get(Meeting, mid) or (_ for _ in ()).throw(HTTPException(404))
        if m.status != "scheduled":
            raise HTTPException(400, f"Meeting is {m.status}")
    asyncio.create_task(wf.start_bot(mid))
    return {"ok": True}


class ResendIn(BaseModel):
    intern_id: int | None = None


@api.post("/meetings/{mid}/resend-invite")
async def resend_invite(mid: int, b: ResendIn | None = None):
    with SessionLocal() as s:
        m = s.get(Meeting, mid) or (_ for _ in ()).throw(HTTPException(404))
        if m.status in ("cancelled",):
            raise HTTPException(400, "Meeting is cancelled")
        iid = b.intern_id if b else None
        if iid is not None and iid not in {i.id for i in m.attendees}:
            raise HTTPException(400, "Intern is not an attendee of this meeting")
    await wf.send_invite(mid, reminder=True, only_intern_id=iid)
    wf.add_log(f"Invite re-sent for meeting #{mid}" + (f" to intern #{iid}" if iid else ""))
    return {"ok": True}


@api.post("/meetings/{mid}/end")
async def force_end(mid: int):
    asyncio.create_task(wf.leave_and_finish(mid))
    return {"ok": True}


@api.post("/meetings/{mid}/cancel")
async def cancel(mid: int):
    with SessionLocal() as s:
        m = s.get(Meeting, mid) or (_ for _ in ()).throw(HTTPException(404))
        if m.status not in ("scheduled", "no_show", "failed"):
            raise HTTPException(400, f"Cannot cancel a {m.status} meeting")
        m.status = "cancelled"
        zid = m.zoom_id
        s.commit()
    if zid:
        try:
            await provider.delete_meeting(zid)
        except Exception as e:
            wf.add_log(f"Could not delete provider meeting for #{mid}: {e}", "warning")
    return {"ok": True}


@api.post("/meetings/{mid}/approve")
async def approve(mid: int):
    with SessionLocal() as s:
        m = s.get(Meeting, mid) or (_ for _ in ()).throw(HTTPException(404))
        if m.status != "awaiting_approval":
            raise HTTPException(400, "Meeting is not awaiting approval")
    await wf.dispatch_kickoff(mid)
    return {"ok": True}


@api.post("/meetings/{mid}/reprocess")
async def reprocess(mid: int):
    with SessionLocal() as s:
        m = s.get(Meeting, mid) or (_ for _ in ()).throw(HTTPException(404))
        if m.status not in ("processed", "awaiting_approval", "failed", "ended"):
            raise HTTPException(400, "Nothing to reprocess yet")
        mtype = m.type
        m.status = "ended"
        s.commit()
    await (wf.process_kickoff(mid) if mtype == "kickoff" else wf.process_review(mid))
    return {"ok": True}


class MeetingPatch(BaseModel):
    title: str | None = None
    scheduled_at: str | None = None
    duration: int | None = None
    join_url: str | None = None
    notify: bool = True


@api.put("/meetings/{mid}")
async def edit_meeting(mid: int, b: MeetingPatch):
    with SessionLocal() as s:
        if not s.get(Meeting, mid):
            raise HTTPException(404)
    try:
        await wf.reschedule_meeting(mid, parse_dt(b.scheduled_at) if b.scheduled_at else None, b.title,
                                    b.duration, b.join_url, b.notify)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return {"ok": True}


def _csv(rows: list[list], header: list[str], name: str) -> Response:
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(header)
    for r in rows:
        # neutralise spreadsheet formula injection
        w.writerow([("'" + c) if isinstance(c, str) and c[:1] in ("=", "+", "-", "@") else c for c in r])
    return Response(buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": f'attachment; filename="{name}.csv"'})


@api.get("/export/tasks.csv")
def export_tasks():
    with SessionLocal() as s:
        rows = [[t.id, t.intern.name, t.intern.email, t.title, t.description, iso(t.deadline), t.status,
                 t.notes.replace("\n", " | "), t.meeting_id, t.review_meeting_id]
                for t in s.scalars(select(Task).order_by(Task.id)).all()]
    return _csv(rows, ["id", "intern", "email", "title", "description", "deadline_utc", "status", "notes",
                       "kickoff_meeting", "review_meeting"], "tasks")


@api.get("/export/meetings.csv")
def export_meetings():
    with SessionLocal() as s:
        rows = [[m.id, m.type, m.title, iso(m.scheduled_at), m.status, m.join_url, m.parent_id,
                 ", ".join(i.name for i in m.attendees), (m.summary or "").replace("\n", " ")]
                for m in s.scalars(select(Meeting).order_by(Meeting.id)).all()]
    return _csv(rows, ["id", "type", "title", "scheduled_utc", "status", "join_url", "parent_id", "attendees", "summary"],
                "meetings")


@api.get("/export/reviews.csv")
def export_reviews():
    with SessionLocal() as s:
        rows = [[r.id, r.meeting_id, r.task_id, r.outcome, r.notes, iso(r.created_at)]
                for r in s.scalars(select(Review).order_by(Review.id)).all()]
    return _csv(rows, ["id", "meeting_id", "task_id", "outcome", "notes", "created_utc"], "reviews")


# ---------------- tasks
@api.get("/tasks")
def tasks(status: str | None = None):
    with SessionLocal() as s:
        q = select(Task).order_by(Task.deadline.is_(None), Task.deadline)
        if status:
            q = q.where(Task.status == status)
        return [task_out(t) for t in s.scalars(q).all()]


@api.post("/tasks")
def add_task(b: TaskIn):
    d = wf.parse_date(b.deadline)
    with SessionLocal() as s:
        t = Task(intern_id=b.intern_id, title=b.title, description=b.description, deadline=wf.deadline_for(d) if d else None)
        s.add(t)
        s.commit()
        return {"id": t.id}


@api.put("/tasks/{tid}")
def edit_task(tid: int, b: TaskPatch):
    with SessionLocal() as s:
        t = s.get(Task, tid) or (_ for _ in ()).throw(HTTPException(404))
        for f in ("title", "description", "notes", "intern_id"):
            if getattr(b, f) is not None:
                setattr(t, f, getattr(b, f))
        if b.status:
            if b.status not in ("assigned", "partial", "not_done", "done", "cancelled"):
                raise HTTPException(400, "bad status")
            t.status = b.status
        if b.deadline is not None:
            d = wf.parse_date(b.deadline)
            t.deadline = wf.deadline_for(d) if d else None
            t.reminded = False
        s.commit()
    return {"ok": True}


@api.delete("/tasks/{tid}")
def del_task(tid: int):
    with SessionLocal() as s:
        t = s.get(Task, tid) or (_ for _ in ()).throw(HTTPException(404))
        s.delete(t)
        s.commit()
    return {"ok": True}


# ---------------- overview / health / logs
@api.get("/stats")
def stats():
    now = utcnow()
    with SessionLocal() as s:
        cnt = lambda q: s.scalar(select(func.count()).select_from(q.subquery()))
        return {
            "interns": cnt(select(Intern).where(Intern.active)),
            "open_tasks": cnt(select(Task).where(Task.status.in_(wf.OPEN))),
            "done_tasks": cnt(select(Task).where(Task.status == "done")),
            "overdue": cnt(select(Task).where(Task.status.in_(wf.OPEN), Task.deadline < now)),
            "upcoming_meetings": cnt(select(Meeting).where(Meeting.status == "scheduled")),
            "live_meetings": cnt(select(Meeting).where(Meeting.status == "live")),
            "awaiting_approval": cnt(select(Meeting).where(Meeting.status == "awaiting_approval")),
        }


@api.get("/health")
def health():
    return {"checks": [
        {"name": "Meeting provider (" + settings.meeting_provider + ")", "ok": provider.configured()},
        {"name": "Recall.ai bot", "ok": bool(settings.recall_api_key)},
        *([{"name": "Google Meet account connected", "ok": meet.configured()}] if settings.meeting_provider == "meet" else []),
        *([{"name": "Zoom host authorized for recording tokens (optional)", "ok": zoom.host_authorized()}] if settings.meeting_provider == "zoom" else []),
        {"name": "Recall status webhook secret (faster call-end detection; polling still works)", "ok": bool(settings.recall_webhook_secret)},
        {"name": "Claude API", "ok": llm.enabled()},
        {"name": "Voice (TTS) - else chat fallback", "ok": tts.enabled()},
        {"name": "Email (SMTP)", "ok": mailer.enabled()},
        {"name": "Public URL is not localhost", "ok": "localhost" not in settings.public_base_url},
        {"name": "Dashboard password changed", "ok": settings.dashboard_password != "change-me"},
        {"name": "Webhook secret changed", "ok": settings.webhook_secret != "change-me-secret"},
    ], "timezone": settings.timezone, "require_approval": settings.require_approval,
        "connections": [c for c in [
            {"label": "Connect Google Meet account", "url": "/oauth/google/start"} if settings.meeting_provider == "meet" else None,
            {"label": "Authorize Zoom host (recording token)", "url": "/oauth/zoom/start"} if settings.meeting_provider == "zoom" and settings.zoom_oauth_client_id else None,
        ] if c]}


@api.get("/logs")
def logs():
    with SessionLocal() as s:
        return [{"ts": iso(l.ts), "level": l.level, "message": l.message}
                for l in s.scalars(select(Log).order_by(Log.id.desc()).limit(100)).all()]


app.include_router(api)


# ---------------- login / logout
@app.get("/login", response_class=HTMLResponse)
def login_page():
    return LOGIN_HTML.replace("__ERR__", "")


@app.post("/login")
async def login(request: Request):
    form = await request.form()
    u, p = str(form.get("username", "")), str(form.get("password", ""))
    ip = _client_ip(request)
    if limiter.blocked(ip):
        return HTMLResponse(LOGIN_HTML.replace("__ERR__", '<div class=e>Too many failed attempts. Try again in 15 minutes.</div>'),
                            status_code=429)
    if secrets.compare_digest(u, settings.dashboard_user) and secrets.compare_digest(p, settings.dashboard_password):
        limiter.success(ip)
        r = RedirectResponse("/", status_code=303)
        r.set_cookie(COOKIE, make_session(u), max_age=SESSION_HOURS * 3600, httponly=True, samesite="lax",
                     secure=settings.public_base_url.startswith("https://"))
        return r
    limiter.fail(ip)
    return HTMLResponse(LOGIN_HTML.replace("__ERR__", '<div class=e>Wrong username or password</div>'), status_code=401)


@app.get("/logout")
def logout():
    r = RedirectResponse("/login", status_code=303)
    r.delete_cookie(COOKIE)
    return r


# ---------------- Recall webhook (token-protected). Recall requires the trailing slash before ?token=
@app.post("/webhooks/recall/")
@app.post("/webhooks/recall")
async def recall_hook(request: Request, token: str = "", meeting_id: int = 0):
    if not secrets.compare_digest(token, settings.webhook_secret):
        raise HTTPException(401, "bad token")
    try:
        body = await request.json()
        asyncio.create_task(wf.on_recall_event(meeting_id, body))
    except Exception as e:
        wf.add_log(f"Webhook error: {e}", "warning")
    return {"ok": True}


# ---------------- OAuth helpers: tokens are stored in the database (no .env editing needed)
def _need_login(request: Request):
    if not (valid_session(request.cookies.get(COOKIE)) or _basic_ok(request)):
        raise HTTPException(401, "login required")


def _redirect_uri(kind: str) -> str:
    return f"{settings.public_base_url.rstrip('/')}/oauth/{kind}/callback"


@app.get("/oauth/google/start")
def google_start(request: Request):
    _need_login(request)
    if not (settings.google_client_id and settings.google_client_secret):
        raise HTTPException(400, "Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET first")
    q = urllib.parse.urlencode({
        "client_id": settings.google_client_id, "redirect_uri": _redirect_uri("google"), "response_type": "code",
        "scope": "https://www.googleapis.com/auth/meetings.space.created", "access_type": "offline", "prompt": "consent",
        "state": make_state("google")})
    return RedirectResponse(f"https://accounts.google.com/o/oauth2/v2/auth?{q}", status_code=303)


@app.get("/oauth/google/callback")
async def google_callback(request: Request, code: str = "", state: str = "", error: str = ""):
    _need_login(request)
    if error or not code or not valid_state(state, "google"):
        raise HTTPException(400, f"Google authorization failed: {error or 'bad state/code'}")
    r = await httpx_retry.request("POST", "https://oauth2.googleapis.com/token", timeout=30, data={
        "code": code, "client_id": settings.google_client_id, "client_secret": settings.google_client_secret,
        "redirect_uri": _redirect_uri("google"), "grant_type": "authorization_code"})
    rt_ = r.json().get("refresh_token")
    if not rt_:
        raise HTTPException(400, "Google returned no refresh token; revoke the app at myaccount.google.com/permissions and retry")
    kv_set("google_refresh_token", rt_)
    meet._tok.update(v=None, exp=0)
    wf.add_log("Google Meet account connected")
    return RedirectResponse("/", status_code=303)


@app.get("/oauth/zoom/start")
def zoom_start(request: Request):
    _need_login(request)
    if not settings.zoom_oauth_client_id:
        raise HTTPException(400, "Set ZOOM_OAUTH_CLIENT_ID and ZOOM_OAUTH_CLIENT_SECRET (a Zoom OAuth app) first")
    q = urllib.parse.urlencode({"response_type": "code", "client_id": settings.zoom_oauth_client_id,
                                "redirect_uri": _redirect_uri("zoom"), "state": make_state("zoom")})
    return RedirectResponse(f"https://zoom.us/oauth/authorize?{q}", status_code=303)


@app.get("/oauth/zoom/callback")
async def zoom_callback(request: Request, code: str = "", state: str = "", error: str = ""):
    _need_login(request)
    if error or not code or not valid_state(state, "zoom"):
        raise HTTPException(400, f"Zoom authorization failed: {error or 'bad state/code'}")
    r = await httpx_retry.request("POST", "https://zoom.us/oauth/token", timeout=30,
                                  params={"grant_type": "authorization_code", "code": code, "redirect_uri": _redirect_uri("zoom")},
                                  auth=(settings.zoom_oauth_client_id, settings.zoom_oauth_client_secret))
    rt_ = r.json().get("refresh_token")
    if not rt_:
        raise HTTPException(400, "Zoom returned no refresh token")
    kv_set("zoom_refresh_token", rt_)
    wf.add_log("Zoom host authorized for recording tokens")
    return RedirectResponse("/", status_code=303)


# ---------------- Recall bot status-change webhook (configure the endpoint in the Recall dashboard)
@app.post("/webhooks/recall-status/")
@app.post("/webhooks/recall-status")
async def recall_status_hook(request: Request):
    raw = await request.body()
    if not recall.verify_signature(settings.recall_webhook_secret, dict(request.headers), raw):
        raise HTTPException(401, "bad signature")
    try:
        body = json.loads(raw or b"{}")
        data = body.get("data") or {}
        bot_id = (data.get("bot") or {}).get("id")
        inner = data.get("data") or {}
        if bot_id:
            asyncio.create_task(wf.on_bot_status(bot_id, inner.get("code") or str(body.get("event", "")).removeprefix("bot."),
                                                 inner.get("sub_code")))
    except Exception as e:
        wf.add_log(f"Status webhook error: {e}", "warning")
    return {"ok": True}


# ---------------- Zoom local-recording join token (UNVERIFIED contract with Recall; see README)
@app.get("/zoom/join-token/")
@app.get("/zoom/join-token")
async def zoom_join_token(token: str = "", meeting_id: int = 0):
    if not secrets.compare_digest(token, settings.webhook_secret):
        raise HTTPException(401, "bad token")
    with SessionLocal() as s:
        m = s.get(Meeting, meeting_id)
        zid = m.zoom_id if m else None
    if not zid or settings.meeting_provider != "zoom":
        raise HTTPException(404, "no zoom meeting")
    try:
        return PlainTextResponse(await zoom.local_recording_token(zid))
    except Exception as e:
        wf.add_log(f"Zoom join token failed for #{meeting_id}: {e}", "error")
        raise HTTPException(502, "could not get join token")


STATIC = Path(__file__).parent / "static"


@app.get("/")
def dashboard(request: Request):
    if not (valid_session(request.cookies.get(COOKIE)) or _basic_ok(request)):
        return RedirectResponse("/login", status_code=303)
    return FileResponse(STATIC / "index.html")
