"""Meeting-provider dispatch: zoom | meet | teams | manual. The provider's own meeting id is stored in Meeting.zoom_id."""
from ..config import settings
from . import meet, teams, zoom


def _mod():
    return {"zoom": zoom, "meet": meet, "teams": teams}.get(settings.meeting_provider)


def can_create() -> bool:
    return _mod() is not None


async def create_meeting(topic: str, start_utc, duration: int = 60) -> tuple[str, str]:
    m = _mod()
    if m is None:
        raise ValueError("join_url is required when MEETING_PROVIDER=manual")
    return await m.create_meeting(topic, start_utc, duration)


async def update_meeting(ext_id: str, topic: str, start_utc, duration: int) -> None:
    m = _mod()
    if m is not None and ext_id:
        await m.update_meeting(ext_id, topic, start_utc, duration)


async def delete_meeting(ext_id: str) -> None:
    m = _mod()
    if m is not None and ext_id:
        await m.delete_meeting(ext_id)


def configured() -> bool:
    p = settings.meeting_provider
    if p == "manual":
        return True
    if p == "zoom":
        return all([settings.zoom_account_id, settings.zoom_client_id, settings.zoom_client_secret, settings.zoom_host_user])
    if p == "meet":
        return meet.configured()
    if p == "teams":
        return teams.configured()
    return False
