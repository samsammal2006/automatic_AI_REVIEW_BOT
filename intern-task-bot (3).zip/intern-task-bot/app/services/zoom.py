import time

import httpx

from ..config import settings
from ..db import kv_get, kv_set
from . import http

_tok = {"v": None, "exp": 0.0}


async def _token() -> str:
    if _tok["v"] and time.time() < _tok["exp"] - 60:
        return _tok["v"]
    r = await http.request(
        "POST", "https://zoom.us/oauth/token",
        params={"grant_type": "account_credentials", "account_id": settings.zoom_account_id},
        auth=(settings.zoom_client_id, settings.zoom_client_secret), timeout=30)
    j = r.json()
    _tok.update(v=j["access_token"], exp=time.time() + int(j.get("expires_in", 3600)))
    return _tok["v"]


async def create_meeting(topic: str, start_utc, duration: int = 60) -> tuple[str, str]:
    """Creates a Zoom meeting owned by the bot's Zoom account (the account is the host)."""
    if not settings.zoom_host_user or settings.zoom_host_user == "me":
        raise ValueError("Set ZOOM_HOST_USER to the Zoom account's email/user id (Server-to-Server apps cannot use 'me')")
    tok = await _token()
    body = {
        "topic": topic,
        "type": 2,
        "start_time": start_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "duration": duration,
        "timezone": "UTC",
        "settings": {
            "join_before_host": True, "waiting_room": False, "mute_upon_entry": False,
            "participant_video": False, "host_video": False, "auto_recording": "none",
            "approval_type": 2, "meeting_authentication": False, "registrants_email_notification": False,
        },
    }
    r = await http.request("POST", f"https://api.zoom.us/v2/users/{settings.zoom_host_user}/meetings",
                           json=body, headers={"Authorization": f"Bearer {tok}"}, timeout=30)
    j = r.json()
    return j["join_url"], str(j["id"])


async def delete_meeting(zoom_id: str) -> None:
    tok = await _token()
    await http.request("DELETE", f"https://api.zoom.us/v2/meetings/{zoom_id}",
                       headers={"Authorization": f"Bearer {tok}"}, timeout=30)


async def update_meeting(zoom_id: str, topic: str, start_utc, duration: int) -> None:
    """PATCH /meetings/{id} (returns 204)."""
    tok = await _token()
    await http.request("PATCH", f"https://api.zoom.us/v2/meetings/{zoom_id}", timeout=30,
                       json={"topic": topic, "type": 2, "start_time": start_utc.strftime("%Y-%m-%dT%H:%M:%SZ"),
                             "duration": duration, "timezone": "UTC"},
                       headers={"Authorization": f"Bearer {tok}"})


def host_authorized() -> bool:
    return bool(settings.zoom_oauth_client_id and settings.zoom_oauth_client_secret and kv_get("zoom_refresh_token"))


async def _user_token() -> str:
    """Access token of the host who authorized the Zoom OAuth app (refresh tokens rotate: store the new one every time)."""
    r = await http.request("POST", "https://zoom.us/oauth/token", timeout=30,
                           params={"grant_type": "refresh_token", "refresh_token": kv_get("zoom_refresh_token")},
                           auth=(settings.zoom_oauth_client_id, settings.zoom_oauth_client_secret))
    j = r.json()
    if j.get("refresh_token"):
        kv_set("zoom_refresh_token", j["refresh_token"])
    return j["access_token"]


async def local_recording_token(zoom_id: str) -> str:
    """GET /meetings/{id}/jointoken/local_recording (scopes meeting:read:local_recording_token[:admin]).
    Zoom docs: the HOST must authorize the OAuth app, so the host's own OAuth token is used when connected
    (dashboard -> System -> Authorize Zoom host); otherwise we fall back to the Server-to-Server token (may be refused).
    Tokens expire after ~120 s, so this is fetched on demand."""
    tok = await _user_token() if host_authorized() else await _token()
    r = await http.request("GET", f"https://api.zoom.us/v2/meetings/{zoom_id}/jointoken/local_recording",
                           params={"bypass_waiting_room": "true"}, headers={"Authorization": f"Bearer {tok}"}, timeout=30)
    return r.json()["token"]
