import asyncio
import datetime as dt
import html
import smtplib
from email.message import EmailMessage

from ..config import settings


def enabled() -> bool:
    return bool(settings.smtp_host and (settings.smtp_from or settings.smtp_user))


def make_ics(uid: str, title: str, start: dt.datetime, minutes: int, url: str | None) -> str:
    f = "%Y%m%dT%H%M%SZ"
    end = start + dt.timedelta(minutes=minutes)
    return "\r\n".join([
        "BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//InternBot//EN", "METHOD:REQUEST", "BEGIN:VEVENT",
        f"UID:{uid}@internbot", f"DTSTAMP:{dt.datetime.now(dt.timezone.utc).strftime(f)}", f"DTSTART:{start.strftime(f)}",
        f"DTEND:{end.strftime(f)}", f"SUMMARY:{title}", f"DESCRIPTION:Join: {url or ''}", f"URL:{url or ''}",
        "END:VEVENT", "END:VCALENDAR", ""])


def _send_sync(to: list[str], subject: str, body_html: str, text: str, ics: str | None, cc: list[str]) -> None:
    msg = EmailMessage()
    msg["From"] = settings.smtp_from or settings.smtp_user
    msg["To"] = ", ".join(to)
    if cc:
        msg["Cc"] = ", ".join(cc)
    msg["Subject"] = subject
    msg.set_content(text)
    msg.add_alternative(body_html, subtype="html")
    if ics:
        msg.add_attachment(ics.encode(), maintype="text", subtype="calendar", filename="invite.ics",
                           params={"method": "REQUEST"})
    if settings.smtp_security == "ssl":
        srv = smtplib.SMTP_SSL(settings.smtp_host, settings.smtp_port, timeout=30)
    else:
        srv = smtplib.SMTP(settings.smtp_host, settings.smtp_port, timeout=30)
        if settings.smtp_security == "starttls":
            srv.starttls()
    try:
        if settings.smtp_user:
            srv.login(settings.smtp_user, settings.smtp_password)
        srv.send_message(msg, to_addrs=to + cc)
    finally:
        srv.quit()


async def send(to: str | list[str], subject: str, body_html: str, text: str, ics: str | None = None,
               cc: list[str] | None = None) -> bool:
    if not enabled():
        return False
    to = [to] if isinstance(to, str) else to
    await asyncio.to_thread(_send_sync, to, subject, body_html, text, ics, cc or [])
    return True


def layout(heading: str, inner: str) -> str:
    return (f'<div style="font-family:Arial,sans-serif;max-width:640px;margin:auto;color:#1f2937">'
            f'<h2 style="color:#4338ca">{html.escape(heading)}</h2>{inner}'
            f'<p style="color:#9ca3af;font-size:12px;margin-top:28px">Sent by {html.escape(settings.bot_name)}</p></div>')


def tasks_table(rows: list[dict]) -> str:
    tr = "".join(
        f'<tr><td style="padding:8px;border-bottom:1px solid #e5e7eb"><b>{html.escape(r["title"])}</b><br>'
        f'<span style="color:#6b7280">{html.escape(r.get("description") or "")}</span></td>'
        f'<td style="padding:8px;border-bottom:1px solid #e5e7eb;white-space:nowrap">{html.escape(r.get("deadline") or "TBD")}</td>'
        f'<td style="padding:8px;border-bottom:1px solid #e5e7eb">{html.escape(r.get("status") or "")}</td></tr>' for r in rows)
    return ('<table style="border-collapse:collapse;width:100%"><tr style="background:#eef2ff"><th align="left" style="padding:8px">Task</th>'
            f'<th align="left" style="padding:8px">Deadline</th><th align="left" style="padding:8px">Status</th></tr>{tr}</table>')
