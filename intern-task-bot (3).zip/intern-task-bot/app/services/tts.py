from ..config import settings
from . import http


def enabled() -> bool:
    p = settings.tts_provider
    return (p == "elevenlabs" and bool(settings.elevenlabs_api_key)) or (p == "openai" and bool(settings.openai_api_key))


async def synthesize(text: str) -> bytes | None:
    if settings.tts_provider == "elevenlabs" and settings.elevenlabs_api_key:
        r = await http.request(
            "POST", f"https://api.elevenlabs.io/v1/text-to-speech/{settings.elevenlabs_voice_id}",
            params={"output_format": "mp3_44100_128"}, timeout=90, retries=2,
            headers={"xi-api-key": settings.elevenlabs_api_key, "Accept": "audio/mpeg"},
            json={"text": text, "model_id": settings.elevenlabs_model_id})
        return r.content
    if settings.tts_provider == "openai" and settings.openai_api_key:
        r = await http.request(
            "POST", "https://api.openai.com/v1/audio/speech", timeout=90, retries=2,
            headers={"Authorization": f"Bearer {settings.openai_api_key}"},
            json={"model": "gpt-4o-mini-tts", "voice": settings.openai_tts_voice, "input": text[:4000], "response_format": "mp3"})
        return r.content
    return None
