"""Microsoft Teams meeting creation via Graph (app-only): POST /users/{userId}/onlineMeetings.

Requirements (per Microsoft docs): application permission OnlineMeetings.ReadWrite.All AND a tenant admin must create
and grant a CsApplicationAccessPolicy for the host user. TEAMS_HOST_USER must be that user's object ID (GUID).
"""
import time

from ..config import settings
from . import http

_tok = {"v": None, "exp": 0.0}
GRAPH = "https://graph.microsoft.com/v1.0"


def configured() -> bool:
    return all([settings.teams_tenant_id, settings.teams_client_id, settings.teams_client_secret, settings.teams_host_user])


async def _token() -> str:
    if _tok["v"] and time.time() < _tok["exp"] - 60:
        return _tok["v"]
    r = await http.request("POST", f"https://login.microsoftonline.com/{settings.teams_tenant_id}/oauth2/v2.0/token",
                           timeout=30, data={"client_id": settings.teams_client_id,
                                             "client_secret": settings.teams_client_secret,
                                             "scope": "https://graph.microsoft.com/.default",
                                             "grant_type": "client_credentials"})
    j = r.json()
    _tok.update(v=j["access_token"], exp=time.time() + int(j.get("expires_in", 3600)))
    return _tok["v"]


def _iso(d) -> str:
    return d.strftime("%Y-%m-%dT%H:%M:%SZ")


def _body(topic, start_utc, duration) -> dict:
    import datetime as dt
    return {"subject": topic, "startDateTime": _iso(start_utc),
            "endDateTime": _iso(start_utc + dt.timedelta(minutes=duration))}


async def create_meeting(topic: str, start_utc, duration: int = 60) -> tuple[str, str]:
    if not configured():
        raise ValueError("Set TEAMS_TENANT_ID, TEAMS_CLIENT_ID, TEAMS_CLIENT_SECRET and TEAMS_HOST_USER for MEETING_PROVIDER=teams")
    tok = await _token()
    body = _body(topic, start_utc, duration)
    # lobbyBypassSettings is documented on the onlineMeeting resource; "everyone" lets the bot in without admission.
    body["lobbyBypassSettings"] = {"scope": "everyone"}
    r = await http.request("POST", f"{GRAPH}/users/{settings.teams_host_user}/onlineMeetings", timeout=30,
                           headers={"Authorization": f"Bearer {tok}"}, json=body)
    j = r.json()
    return j["joinWebUrl"], j["id"]


async def update_meeting(meeting_id: str, topic: str, start_utc, duration: int) -> None:
    tok = await _token()
    await http.request("PATCH", f"{GRAPH}/users/{settings.teams_host_user}/onlineMeetings/{meeting_id}", timeout=30,
                       headers={"Authorization": f"Bearer {tok}"}, json=_body(topic, start_utc, duration))


async def delete_meeting(meeting_id: str) -> None:
    tok = await _token()
    await http.request("DELETE", f"{GRAPH}/users/{settings.teams_host_user}/onlineMeetings/{meeting_id}", timeout=30,
                       headers={"Authorization": f"Bearer {tok}"})
