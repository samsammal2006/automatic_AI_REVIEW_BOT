"""Pure-stdlib validation of LLM output (no network, no settings) so it is unit-testable anywhere.

Rules: never trust model JSON. Dates must be real ISO dates, not in the past, and within a sane horizon;
task ids must belong to the known set; e-mails must match a known intern; wrong types are dropped, not crashed on."""
import json
import re
from datetime import date, datetime, timedelta

STATUSES = ("done", "partial", "not_done", "unclear")


def parse_json(text):
    """Extract the first balanced JSON object/array from text (handles ```json fences and chatter). Raises ValueError."""
    if not isinstance(text, str) or not text.strip():
        raise ValueError("empty LLM output")
    t = re.sub(r"```(?:json)?", "", text).strip()
    start = next((i for i, c in enumerate(t) if c in "{["), -1)
    if start < 0:
        raise ValueError("no JSON found")
    opener = t[start]
    closer = "}" if opener == "{" else "]"
    depth, in_str, esc = 0, False, False
    for i in range(start, len(t)):
        c = t[i]
        if in_str:
            if esc:
                esc = False
            elif c == "\\":
                esc = True
            elif c == '"':
                in_str = False
            continue
        if c == '"':
            in_str = True
        elif c == opener:
            depth += 1
        elif c == closer:
            depth -= 1
            if depth == 0:
                return json.loads(t[start:i + 1])
    raise ValueError("unbalanced JSON")


def _as_date(v, today: date):
    """Return an ISO date string if v is a valid date that is today or later and < 1 year out, else None."""
    if not isinstance(v, str):
        return None
    try:
        d = datetime.strptime(v.strip()[:10], "%Y-%m-%d").date()
    except ValueError:
        return None
    if d < today or d > today + timedelta(days=365):
        return None
    return d.isoformat()


def clean_date(v, today_iso: str):
    return _as_date(v, date.fromisoformat(today_iso))


def _lst(v):
    return v if isinstance(v, list) else []


def clean_plan(d, valid_task_ids, valid_emails, today_iso: str) -> dict:
    out = {"tasks": [], "new_tasks": [], "review_date": None}
    if not isinstance(d, dict):
        return out
    today = date.fromisoformat(today_iso)
    ids = {int(i) for i in valid_task_ids}
    emails = {e.lower() for e in valid_emails}
    seen = set()
    for t in _lst(d.get("tasks")):
        if not isinstance(t, dict):
            continue
        try:
            tid = int(t.get("id"))
        except (TypeError, ValueError):
            continue
        if tid not in ids or tid in seen:
            continue
        seen.add(tid)
        notes = t.get("notes")
        out["tasks"].append({"id": tid, "deadline": _as_date(t.get("deadline"), today),
                             "notes": notes.strip()[:500] if isinstance(notes, str) and notes.strip() else None})
    for t in _lst(d.get("new_tasks")):
        if not isinstance(t, dict):
            continue
        email = str(t.get("intern_email") or "").strip().lower()
        title = str(t.get("title") or "").strip()
        if email not in emails or not title:
            continue
        out["new_tasks"].append({"intern_email": email, "title": title[:200],
                                 "description": str(t.get("description") or "").strip()[:1000],
                                 "deadline": _as_date(t.get("deadline"), today)})
    out["review_date"] = _as_date(d.get("review_date"), today)
    return out


def clean_status(d, today_iso: str, fallback_notes: str):
    """Returns a normalized dict or None when the model output is unusable."""
    if not isinstance(d, dict) or d.get("status") not in STATUSES:
        return None
    notes = d.get("notes")
    return {"status": d["status"],
            "notes": notes.strip()[:500] if isinstance(notes, str) and notes.strip() else fallback_notes,
            "new_deadline": _as_date(d.get("new_deadline"), date.fromisoformat(today_iso))}
