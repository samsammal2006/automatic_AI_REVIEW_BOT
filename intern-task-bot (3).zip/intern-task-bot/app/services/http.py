"""Shared HTTP helper: retries with exponential backoff on network errors, 429 and 5xx."""
import asyncio
import logging

import httpx

log = logging.getLogger("internbot.http")
RETRY_STATUS = {429, 500, 502, 503, 504}


async def request(method: str, url: str, *, retries: int = 3, timeout: float = 60, **kw) -> httpx.Response:
    delay = 1.0
    last: Exception | None = None
    for attempt in range(retries + 1):
        try:
            async with httpx.AsyncClient(timeout=timeout) as c:
                r = await c.request(method, url, **kw)
            if r.status_code in RETRY_STATUS and attempt < retries:
                wait = delay
                ra = r.headers.get("retry-after")
                if ra and ra.isdigit():
                    wait = min(float(ra), 30)
                log.warning("%s %s -> %s, retrying in %.1fs", method, url, r.status_code, wait)
                await asyncio.sleep(wait)
                delay *= 2
                continue
            r.raise_for_status()
            return r
        except (httpx.TransportError, httpx.TimeoutException) as e:
            last = e
            if attempt >= retries:
                break
            log.warning("%s %s failed (%s), retrying in %.1fs", method, url, e, delay)
            await asyncio.sleep(delay)
            delay *= 2
    raise last or RuntimeError("request failed")
