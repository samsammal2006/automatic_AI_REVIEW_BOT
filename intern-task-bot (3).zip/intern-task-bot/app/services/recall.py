import base64
import hashlib
import hmac
import time

import httpx

from ..config import settings
from . import http

# ~0.1s of valid silent MP3 frames; Recall requires automatic_audio_output at bot creation to enable output_audio.
_SILENCE = base64.b64encode((bytes([0xFF, 0xFB, 0x90, 0x64]) + b"\x00" * 413) * 4).decode()


def _base() -> str:
    return f"https://{settings.recall_region}.recall.ai/api/v1"


def _h() -> dict:
    return {"Authorization": f"Token {settings.recall_api_key}", "Content-Type": "application/json"}


async def _req(method: str, path: str, **kw):
    r = await http.request(method, f"{_base()}{path}", headers=_h(), **kw)
    return r.json() if r.content else {}


async def create_bot(meeting_id: int, join_url: str) -> str:
    # Recall requires a trailing slash before the query string, otherwise it answers HTTP 400.
    hook = f"{settings.public_base_url.rstrip('/')}/webhooks/recall/?token={settings.webhook_secret}&meeting_id={meeting_id}"
    body = {
        "meeting_url": join_url,
        "bot_name": settings.bot_name,
        "recording_config": {
            "transcript": {"provider": {"recallai_streaming": {}}},
            "realtime_endpoints": [{
                "type": "webhook", "url": hook,
                "events": ["transcript.data", "participant_events.join", "participant_events.leave"],
            }],
        },
        "automatic_audio_output": {"in_call_recording": {"data": {"kind": "mp3", "b64_data": _SILENCE}}},
    }
    # VERIFIED (docs.recall.ai/docs/providing-zoom-join-tokens): Recall does an HTTP GET to zoom.join_token_url just before
    # joining and uses the plain-text response body as the Zoom "join token for local recording".
    jt = settings.zoom_join_token_url or (
        f"{settings.public_base_url.rstrip('/')}/zoom/join-token/?token={settings.webhook_secret}&meeting_id={meeting_id}"
        if settings.zoom_auto_join_token else "")
    if jt:
        body["zoom"] = {"join_token_url": jt}
    return (await _req("POST", "/bot/", json=body))["id"]


async def get_bot(bot_id: str) -> dict:
    return await _req("GET", f"/bot/{bot_id}/")


def status_code(bot: dict) -> str | None:
    ch = bot.get("status_changes") or []
    return ch[-1].get("code") if ch else None


def status_codes(bot: dict) -> list[str]:
    return [c.get("code") for c in (bot.get("status_changes") or []) if c.get("code")]


def sub_code(bot: dict, code: str) -> str | None:
    for c in reversed(bot.get("status_changes") or []):
        if c.get("code") == code:
            return c.get("sub_code")
    return None


async def send_chat(bot_id: str, text: str) -> None:
    await _req("POST", f"/bot/{bot_id}/send_chat_message/", json={"message": text[:4000]})


async def output_audio(bot_id: str, mp3: bytes) -> None:
    await _req("POST", f"/bot/{bot_id}/output_audio/",
               json={"kind": "mp3", "b64_data": base64.b64encode(mp3).decode()})


async def leave(bot_id: str) -> None:
    await _req("POST", f"/bot/{bot_id}/leave_call/")


async def fetch_transcript(bot: dict) -> list[tuple[str, str]]:
    """Fallback: download Recall's own transcript if realtime utterances were not captured."""
    out: list[tuple[str, str]] = []
    for rec in bot.get("recordings") or []:
        url = ((((rec.get("media_shortcuts") or {}).get("transcript") or {}).get("data") or {}).get("download_url"))
        if not url:
            continue
        r = await http.request("GET", url)  # pre-signed URL: no auth header
        if True:
            for seg in r.json():
                words = " ".join(w.get("text", "") for w in seg.get("words", []))
                out.append(((seg.get("participant") or {}).get("name") or "Unknown", words))
    return out


def verify_signature(secret: str, headers: dict, raw: bytes) -> bool:
    """Verify Recall (Svix-style) webhook signatures: HMAC-SHA256 over '{id}.{timestamp}.{body}', key = base64(secret w/o whsec_).
    Headers are webhook-* (new accounts) or svix-* (accounts before Dec 15 2025). Rejects if the secret is unset."""
    h = {k.lower(): v for k, v in headers.items()}
    mid = h.get("webhook-id") or h.get("svix-id")
    ts = h.get("webhook-timestamp") or h.get("svix-timestamp")
    sig = h.get("webhook-signature") or h.get("svix-signature")
    if not (secret.startswith("whsec_") and mid and ts and sig):
        return False
    try:
        if abs(time.time() - int(ts)) > 600:  # replay protection (docs set no tolerance; this is our own choice)
            return False
        key = base64.b64decode(secret[len("whsec_"):])
    except Exception:
        return False
    expected = hmac.new(key, f"{mid}.{ts}.".encode() + raw, hashlib.sha256).digest()
    for entry in sig.split(" "):
        ver, _, val = entry.partition(",")
        if ver != "v1" or not val:
            continue
        try:
            if hmac.compare_digest(base64.b64decode(val), expected):
                return True
        except Exception:
            continue
    return False
