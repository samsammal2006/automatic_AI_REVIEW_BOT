"""Google Meet space creation via the Meet REST API (POST https://meet.googleapis.com/v2/spaces).

Auth: a *user* OAuth refresh token (scope https://www.googleapis.com/auth/meetings.space.created) belonging to the
account that should own the meetings. Get one once with the OAuth playground / the helper in the README.
accessType OPEN = anyone with the link joins without knocking, so the Recall bot is admitted automatically.
Meet spaces have no start time or title: scheduling lives in our emails/.ics, so update/delete are no-ops.
"""
import time

from ..config import settings
from ..db import kv_get
from . import http

_tok = {"v": None, "exp": 0.0}


def refresh_token() -> str:
    return settings.google_refresh_token or kv_get("google_refresh_token")


def configured() -> bool:
    return all([settings.google_client_id, settings.google_client_secret, refresh_token()])


async def _token() -> str:
    if _tok["v"] and time.time() < _tok["exp"] - 60:
        return _tok["v"]
    r = await http.request("POST", "https://oauth2.googleapis.com/token", timeout=30, data={
        "client_id": settings.google_client_id, "client_secret": settings.google_client_secret,
        "refresh_token": refresh_token(), "grant_type": "refresh_token"})
    j = r.json()
    _tok.update(v=j["access_token"], exp=time.time() + int(j.get("expires_in", 3600)))
    return _tok["v"]


async def create_meeting(topic: str, start_utc, duration: int = 60) -> tuple[str, str]:
    if not configured():
        raise ValueError("Set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET, then click 'Connect Google Meet account' in Dashboard > System (or set GOOGLE_REFRESH_TOKEN)")
    tok = await _token()
    r = await http.request("POST", "https://meet.googleapis.com/v2/spaces", timeout=30,
                           headers={"Authorization": f"Bearer {tok}"}, json={"config": {"accessType": "OPEN"}})
    j = r.json()
    return j["meetingUri"], j["name"]


async def update_meeting(*_a, **_k) -> None:
    return None


async def delete_meeting(*_a, **_k) -> None:
    return None
