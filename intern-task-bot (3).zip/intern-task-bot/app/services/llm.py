import json
import re

from ..config import settings
from . import http


def provider() -> str | None:
    """'claude' if an Anthropic key is set, else 'gemini' (free tier) if a Gemini key is set, else None."""
    if settings.anthropic_api_key:
        return "claude"
    if settings.gemini_api_key:
        return "gemini"
    return None


def enabled() -> bool:
    return provider() is not None


def model_name() -> str:
    return settings.claude_model if provider() == "claude" else settings.gemini_model


async def _ask_gemini(system: str, user: str, max_tokens: int) -> str:
    # maxOutputTokens is floored because newer Gemini models count internal "thinking" tokens against it.
    r = await http.request(
        "POST", f"https://generativelanguage.googleapis.com/v1beta/models/{settings.gemini_model}:generateContent",
        timeout=90, retries=2,
        headers={"x-goog-api-key": settings.gemini_api_key, "content-type": "application/json"},
        json={"systemInstruction": {"parts": [{"text": system}]},
              "contents": [{"role": "user", "parts": [{"text": user}]}],
              "generationConfig": {"maxOutputTokens": max(max_tokens, 1024)}})
    cands = r.json().get("candidates") or []
    parts = ((cands[0].get("content") or {}).get("parts") or []) if cands else []
    return "".join(p.get("text", "") for p in parts)


async def ask(system: str, user: str, max_tokens: int = 1200) -> str:
    if provider() == "gemini":
        return await _ask_gemini(system, user, max_tokens)
    r = await http.request(
        "POST", "https://api.anthropic.com/v1/messages", timeout=90, retries=2,
        headers={"x-api-key": settings.anthropic_api_key, "anthropic-version": "2023-06-01",
                 "content-type": "application/json"},
        json={"model": settings.claude_model, "max_tokens": max_tokens, "system": system,
              "messages": [{"role": "user", "content": user}]})
    return "".join(b.get("text", "") for b in r.json().get("content", []))


from .llm_safety import parse_json, clean_plan, clean_status  # noqa: E402


QUESTION_WORDS = {"what", "when", "where", "who", "why", "how", "which", "can", "could", "should", "is", "are",
                  "do", "does", "will", "would", "may"}


def looks_like_question(text: str) -> bool:
    t = text.strip().lower()
    if len(t.split()) < 3:
        return False
    return "?" in t or t.split()[0] in QUESTION_WORDS or settings.bot_name.lower() in t


async def briefing(bot_name: str, title: str, tasks: list[dict]) -> list[str]:
    """Returns spoken paragraphs: intro, one per intern, closing."""
    if enabled():
        try:
            txt = await ask(
                f"You are {bot_name}, an AI assistant hosting a task-assignment meeting for interns. Write a spoken "
                "briefing: warm, clear, no markdown, no bullet symbols. Start with a short intro, then one paragraph "
                "per intern explaining each of their tasks (what to do, expected outcome, deadline if given), "
                "and end with a one-sentence invitation for questions. Separate paragraphs with a blank line.",
                f"Meeting: {title}\nTasks JSON: {json.dumps(tasks)}", 1500)
            paras = [p.strip() for p in txt.split("\n\n") if p.strip()]
            if paras:
                return paras
        except Exception:
            pass
    by: dict[str, list[dict]] = {}
    for t in tasks:
        by.setdefault(t["intern"], []).append(t)
    paras = [f"Hello everyone, I'm {bot_name}. Today's meeting is {title}. I'll walk you through your tasks."]
    for name, ts in by.items():
        parts = []
        for t in ts:
            dl = f", due {t['deadline']}" if t.get("deadline") else ""
            parts.append(f"{t['title']}{dl}. {t.get('description') or ''}".strip())
        paras.append(f"{name}, your tasks are: " + " Next, ".join(parts))
    paras.append("That's everything. Does anyone have questions?")
    return paras


async def answer(bot_name: str, question: str, speaker: str, context: str) -> str:
    if enabled():
        try:
            return (await ask(
                f"You are {bot_name}, an AI assistant in a live intern meeting. Answer in at most 3 short spoken "
                "sentences, plain text. Use only the task context given. If you don't know, say you'll flag it to "
                "the mentor.", f"Context:\n{context}\n\n{speaker} asked: {question}", 300)).strip()
        except Exception:
            pass
    return "Good question. I've noted it and I'll flag it to the mentor to follow up."


async def extract_plan(transcript: str, tasks: list[dict], interns: list[dict], today: str) -> dict:
    empty = {"tasks": [], "new_tasks": [], "review_date": None}
    if not enabled() or not transcript.strip():
        return empty
    try:
        txt = await ask(
            "You extract structured data from a meeting transcript. Output ONLY JSON, no prose. Schema: "
            '{"tasks":[{"id":int,"deadline":"YYYY-MM-DD"|null,"notes":string|null}],'
            '"new_tasks":[{"intern_email":string,"title":string,"description":string,"deadline":"YYYY-MM-DD"|null}],'
            '"review_date":"YYYY-MM-DD"|null}. Only use deadlines/review dates explicitly stated or clearly implied '
            "by speakers; resolve relative dates against today. Never invent dates. new_tasks only for tasks "
            "newly assigned verbally that are not already in the list.",
            f"Today: {today}\nExisting tasks: {json.dumps(tasks)}\nInterns: {json.dumps(interns)}\n"
            f"Transcript:\n{transcript[-60000:]}", 2000)
        return clean_plan(parse_json(txt), [t["id"] for t in tasks if "id" in t],
                          [i.get("email", "") for i in interns], today)
    except Exception:
        return empty


def _heuristic_status(reply: str) -> dict:
    t = reply.lower()
    if re.search(r"\b(not (yet )?(done|finished|started|complete)|haven'?t|didn'?t|blocked|stuck)\b", t):
        return {"status": "not_done", "notes": reply, "new_deadline": None}
    if re.search(r"\b(partly|partially|half|in progress|almost|still working|ongoing)\b", t):
        return {"status": "partial", "notes": reply, "new_deadline": None}
    if re.search(r"\b(done|finished|completed|complete|submitted|delivered)\b", t):
        return {"status": "done", "notes": reply, "new_deadline": None}
    return {"status": "unclear", "notes": reply, "new_deadline": None}


async def classify_status(task: dict, reply: str, today: str) -> dict:
    if enabled():
        try:
            txt = await ask(
                "Classify an intern's spoken status update on a task. Output ONLY JSON: "
                '{"status":"done"|"partial"|"not_done"|"unclear","notes":"one-sentence summary",'
                '"new_deadline":"YYYY-MM-DD"|null}. new_deadline only if the intern stated when they can finish. '
                "Use unclear only if the reply says nothing about progress.",
                f"Today: {today}\nTask: {json.dumps(task)}\nIntern said: {reply}", 300)
            r = clean_status(parse_json(txt), today, reply)
            if r:
                return r
        except Exception:
            pass
    return _heuristic_status(reply)


async def summarize_review(lines: list[str]) -> str:
    base = "\n".join(lines)
    if enabled():
        try:
            return (await ask("Summarize this intern task review for a mentor in under 120 words, plain text.",
                              base, 400)).strip()
        except Exception:
            pass
    return base
