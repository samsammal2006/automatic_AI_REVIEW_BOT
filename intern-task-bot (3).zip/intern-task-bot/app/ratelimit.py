"""Tiny in-memory failed-login limiter (stdlib only). Per client key: max_fails failures within window seconds -> locked."""
import time


class LoginLimiter:
    def __init__(self, max_fails: int = 5, window: int = 900):
        self.max_fails, self.window = max_fails, window
        self._fails: dict[str, list[float]] = {}

    def _prune(self, key: str, now: float) -> list[float]:
        xs = [t for t in self._fails.get(key, []) if now - t < self.window]
        if xs:
            self._fails[key] = xs
        else:
            self._fails.pop(key, None)
        return xs

    def blocked(self, key: str, now: float | None = None) -> bool:
        return len(self._prune(key, now if now is not None else time.time())) >= self.max_fails

    def fail(self, key: str, now: float | None = None) -> None:
        now = now if now is not None else time.time()
        self._prune(key, now)
        self._fails.setdefault(key, []).append(now)
        if len(self._fails) > 5000:  # bound memory under attack
            self._fails = {k: v for k, v in self._fails.items() if now - v[-1] < self.window}

    def success(self, key: str) -> None:
        self._fails.pop(key, None)
