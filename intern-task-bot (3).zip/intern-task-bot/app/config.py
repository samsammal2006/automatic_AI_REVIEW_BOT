from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    public_base_url: str = "http://localhost:8000"
    webhook_secret: str = "change-me-secret"
    dashboard_user: str = "admin"
    dashboard_password: str = "change-me"
    database_url: str = "sqlite:///./data/bot.db"
    timezone: str = "UTC"
    mentor_email: str = ""

    meeting_provider: str = "manual"
    zoom_account_id: str = ""
    zoom_client_id: str = ""
    zoom_client_secret: str = ""
    zoom_host_user: str = ""  # REQUIRED for Zoom: the bot account's email or user id (Server-to-Server apps cannot use "me")
    zoom_join_token_url: str = ""  # optional override: your own URL that supplies a Zoom join token to Recall
    zoom_oauth_client_id: str = ""      # separate Zoom *OAuth* app (user-managed) so the host can authorize recording tokens
    zoom_oauth_client_secret: str = ""
    zoom_auto_join_token: bool = False  # use the built-in /zoom/join-token endpoint (field + plain-text GET contract)
    session_secret: str = ""  # signs dashboard login cookies; defaults to webhook_secret

    # Google Meet (MEETING_PROVIDER=meet): user OAuth refresh token, scope meetings.space.created
    google_client_id: str = ""
    google_client_secret: str = ""
    google_refresh_token: str = ""

    # Microsoft Teams (MEETING_PROVIDER=teams): app-only Graph, needs an application access policy for the host user
    teams_tenant_id: str = ""
    teams_client_id: str = ""
    teams_client_secret: str = ""
    teams_host_user: str = ""  # host user's object ID (GUID)

    recall_api_key: str = ""
    recall_webhook_secret: str = ""  # whsec_... from Recall dashboard; enables POST /webhooks/recall-status/
    recall_region: str = "us-east-1"
    bot_name: str = "Task Bot"

    anthropic_api_key: str = ""
    claude_model: str = "claude-sonnet-5-5"
    gemini_api_key: str = ""  # FREE alternative brain (aistudio.google.com, no card); used only if ANTHROPIC_API_KEY is empty
    gemini_model: str = "gemini-flash-lite-latest"

    tts_provider: str = "none"
    elevenlabs_api_key: str = ""
    elevenlabs_voice_id: str = "21m00Tcm4TlvDq8ikWAM"
    elevenlabs_model_id: str = "eleven_flash_v2_5"  #: current low-latency model (turbo_v2_5 deprecated); GET /v1/models lists ids
    openai_api_key: str = ""
    openai_tts_voice: str = "alloy"

    smtp_host: str = ""
    smtp_port: int = 587
    smtp_user: str = ""
    smtp_password: str = ""
    smtp_from: str = ""
    smtp_security: str = "starttls"

    default_deadline_days: int = 5
    review_hour: int = 11
    followup_days: int = 3
    bot_lead_minutes: int = 2
    max_meeting_minutes: int = 90
    require_approval: bool = False


settings = Settings()
