"""Live go-live check: `python -m app.preflight --email you@example.com [--create-meeting]`.
Exercises every external dependency once and prints PASS/FAIL/SKIP with the reason. Exit code 1 if anything FAILED."""
import argparse
import asyncio
import datetime as dt
import sys

from .config import settings
from .db import init_db, utcnow
from .services import http, llm, mailer, meet, provider, recall, teams, tts, zoom


async def _check(name, coro_fn, results):
    try:
        out = await coro_fn()
        if out is None:
            results.append((name, "SKIP", "not configured"))
        else:
            results.append((name, "PASS", str(out)))
    except Exception as e:  # noqa: BLE001
        detail = str(e)
        resp = getattr(e, "response", None)
        if resp is not None:
            detail += f" | {resp.status_code} {resp.text[:300]}"
        results.append((name, "FAIL", detail))


async def main(email: str, create_meeting: bool) -> int:
    init_db()
    res: list = []

    async def cfg():
        bad = [n for n, ok in [("PUBLIC_BASE_URL still localhost", "localhost" not in settings.public_base_url),
                               ("WEBHOOK_SECRET default", settings.webhook_secret != "change-me-secret"),
                               ("DASHBOARD_PASSWORD default", settings.dashboard_password != "change-me")] if not ok]
        if bad:
            raise RuntimeError("; ".join(bad))
        return "secrets changed, public URL set"

    async def public():
        if "localhost" in settings.public_base_url:
            raise RuntimeError("Recall cannot reach localhost; use a public https URL (ngrok/cloudflared/VPS)")
        r = await http.request("GET", settings.public_base_url.rstrip("/") + "/login", retries=1, timeout=15)
        return f"{settings.public_base_url} reachable ({r.status_code})"

    async def rec():
        if not settings.recall_api_key:
            return None
        r = await http.request("GET", f"{recall._base()}/bot/", headers=recall._h(), retries=1, timeout=20)
        return f"Recall key accepted ({settings.recall_region})"

    async def claude():
        if not llm.enabled():
            return None
        t = await llm.ask("Reply with the single word OK.", "ping", 10)
        return f"{llm.provider()} replied: {t.strip()[:20]!r} (model {llm.model_name()})"

    async def voice():
        if not tts.enabled():
            return None
        audio = await tts.synthesize("Hello, this is the task bot voice test.")
        if not audio or len(audio) < 1000:
            raise RuntimeError("TTS returned no/very small audio")
        return f"{settings.tts_provider}: {len(audio)} bytes of mp3"

    async def smtp():
        if not mailer.enabled():
            return None
        ok = await mailer.send(email, "Intern Task Bot preflight", mailer.layout("Preflight", "<p>SMTP works.</p>"), "SMTP works.")
        if not ok:
            raise RuntimeError("send returned False")
        return f"test mail sent to {email}"

    async def prov():
        if not provider.can_create():
            return "manual mode: you paste links (nothing to test)"
        if not provider.configured():
            raise RuntimeError(f"MEETING_PROVIDER={settings.meeting_provider} is not fully configured")
        if not create_meeting:
            return "configured (use --create-meeting to create + delete a real test meeting)"
        url, ext = await provider.create_meeting("Preflight test", utcnow() + dt.timedelta(hours=2), 15)
        try:
            await provider.delete_meeting(ext)
        except Exception:  # noqa: BLE001
            pass
        return f"created {url}"

    for name, fn in [("Config sanity", cfg), ("Public URL reachable", public), ("Recall.ai API key", rec), ("Claude API", claude),
                     ("Voice (TTS)", voice), ("SMTP email", smtp), (f"Meeting provider ({settings.meeting_provider})", prov)]:
        await _check(name, fn, res)
    w = max(len(n) for n, *_ in res)
    for n, st, d in res:
        print(f"[{st}] {n.ljust(w)}  {d}")
    print("\nNOT testable here: bot actually hearing/speaking in a live meeting - run one real 2-minute test kickoff with yourself as the intern.")
    return 1 if any(st == "FAIL" for _, st, _ in res) else 0


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--email", default=settings.mentor_email or settings.smtp_from, help="where to send the SMTP test mail")
    ap.add_argument("--create-meeting", action="store_true", help="create and delete one real test meeting on the provider")
    a = ap.parse_args()
    sys.exit(asyncio.run(main(a.email, a.create_meeting)))
