import asyncio, datetime as dt, os
os.environ["DATABASE_URL"] = "sqlite:///./data/test.db"
os.environ["ANTHROPIC_API_KEY"] = ""
import pytest
from app import workflow as wf
from app.db import Base, engine, SessionLocal, Intern, Task, Meeting, utcnow
from app.services import llm, mailer, recall


@pytest.fixture(autouse=True)
def fresh(monkeypatch):
    Base.metadata.drop_all(engine); Base.metadata.create_all(engine)
    sent, spoken = [], []
    async def fake_send(to, subject, *a, **k): sent.append((to, subject)); return True
    async def fake_speak(mid, bot, text): spoken.append(text)
    async def fake_zoom(topic, start, dur=60): return "https://zoom.us/j/1", "1"
    async def fake_leave(b): pass
    monkeypatch.setattr(mailer, "send", fake_send)
    monkeypatch.setattr(wf, "speak", fake_speak)
    monkeypatch.setattr(wf.zoom, "create_meeting", fake_zoom)
    monkeypatch.setattr(recall, "leave", fake_leave)
    # no test may touch the network (real calls would hit retry/backoff)
    async def fake_get_bot(b): return {}
    async def noop(*a, **k): return None
    monkeypatch.setattr(recall, "get_bot", fake_get_bot)
    monkeypatch.setattr(recall, "send_chat", noop)
    monkeypatch.setattr(recall, "output_audio", noop)
    monkeypatch.setattr(wf.zoom, "update_meeting", noop)
    monkeypatch.setattr(wf.zoom, "delete_meeting", noop)
    real_sleep = asyncio.sleep
    async def fast_sleep(_): await real_sleep(0)
    monkeypatch.setattr(wf.asyncio, "sleep", fast_sleep)
    monkeypatch.setattr(wf.settings, "mentor_email", "mentor@x.com")
    return sent, spoken


def seed():
    with SessionLocal() as s:
        out = []
        for n, e in (("Asha Rao", "asha@x.com"), ("Ben Lee", "ben@x.com")):
            i = s.query(Intern).filter(Intern.email == e).first()
            if not i:
                i = Intern(name=n, email=e); s.add(i); s.commit()
            out.append(i.id)
        return out[0], out[1]


def test_question_detection():
    assert llm.looks_like_question("when is the deadline for this")
    assert llm.looks_like_question("deadline is Friday right?")
    assert not llm.looks_like_question("ok thanks")


def test_status_heuristic():
    assert llm._heuristic_status("I finished it yesterday")["status"] == "done"
    assert llm._heuristic_status("not done yet, I'm stuck")["status"] == "not_done"
    assert llm._heuristic_status("partially, still working")["status"] == "partial"


def test_full_cycle(fresh):
    sent, spoken = fresh
    a, b = seed()
    async def run():
        kid = await wf.create_meeting("kickoff", "Kick", utcnow() + dt.timedelta(days=1), [a, b])
        with SessionLocal() as s:
            s.add(Task(intern_id=a, title="Build API", meeting_id=kid)); s.add(Task(intern_id=b, title="Write docs", meeting_id=kid)); s.commit()
            s.get(Meeting, kid).status = "live"; s.get(Meeting, kid).bot_id = "bot1"; s.commit()
        wf.upd_state(kid, briefed=True)
        await wf.finish(kid)                                   # kickoff post-processing
        st = wf.get_state(kid); rid = st["review_meeting_id"]
        with SessionLocal() as s:
            tasks = s.query(Task).all()
            assert all(t.deadline for t in tasks) and all(t.review_meeting_id == rid for t in tasks)
            assert s.get(Meeting, kid).status == "processed"
        assert sum(1 for to, sub in sent if "Your tasks" in sub) == 2
        # review: Asha done, Ben not done
        with SessionLocal() as s:
            s.get(Meeting, rid).status = "live"; s.get(Meeting, rid).bot_id = "bot2"; s.commit()
        await wf.run_review_intro(rid)
        q = wf.get_state(rid)["queue"]
        await wf.apply_answer(rid, q[0], "done", "all complete", None)
        await wf.apply_answer(rid, q[1], "not_done", "blocked", None)
        with SessionLocal() as s:
            st2 = {t.title: t.status for t in s.query(Task).all()}
            assert sorted(st2.values()) == ["done", "not_done"]
            nxt = wf.get_state(rid).get("next_review_meeting_id")
            assert nxt and s.get(Meeting, rid).status == "processed"
            assert s.query(Task).filter(Task.review_meeting_id == nxt).count() == 1
    asyncio.run(run())


# ---------------------------------------------------------------- hardening tests
def _make_live(kind="review"):
    a, b = seed()
    async def mk():
        mid = await wf.create_meeting(kind, "T", utcnow() + dt.timedelta(days=1), [a, b], notify=False)
        with SessionLocal() as s:
            m = s.get(Meeting, mid); m.status = "live"; m.bot_id = "botX"; s.commit()
        return mid
    return asyncio.run(mk()), a, b


def test_duplicate_transcript_webhook_is_ignored():
    mid, a, b = _make_live("kickoff")
    wf.upd_state(mid, briefed=False)
    body = {"event": "transcript.data", "data": {"data": {
        "words": [{"text": "hello", "start_timestamp": {"relative": 1.5}}, {"text": "team", "start_timestamp": {"relative": 2.0}}],
        "participant": {"id": 7, "name": "Asha Rao"}}}}
    async def run():
        await wf.on_recall_event(mid, body)
        await wf.on_recall_event(mid, body)   # Recall retry
    asyncio.run(run())
    from app.db import Utterance
    with SessionLocal() as s:
        assert s.query(Utterance).filter(Utterance.meeting_id == mid).count() == 1


def test_join_leave_tracking_and_bot_ignored():
    mid, a, b = _make_live("kickoff")
    ev = lambda e, pid, name: {"event": e, "data": {"data": {"participant": {"id": pid, "name": name}}}}
    async def run():
        await wf.on_recall_event(mid, ev("participant_events.join", 1, "Asha Rao"))
        await wf.on_recall_event(mid, ev("participant_events.join", 99, wf.settings.bot_name))
    asyncio.run(run())
    st = wf.get_state(mid)
    assert st["ever_joined"] and list(st["participants"].values()) == ["Asha Rao"]
    asyncio.run(wf.on_recall_event(mid, ev("participant_events.leave", 1, "Asha Rao")))
    st = wf.get_state(mid)
    assert st["participants"] == {} and st["empty_since"]


def test_restart_recovery():
    mid, a, b = _make_live("kickoff")
    wf.upd_state(mid, intro_started=True, briefed=False, finishing=True)
    mid2, _, _ = _make_live("review")
    wf.upd_state(mid2, intro_started=True, briefed=False)
    with SessionLocal() as s:
        m = Meeting(type="kickoff", title="S", scheduled_at=utcnow(), join_url="x", status="starting")
        s.add(m); s.commit(); sid = m.id
    asyncio.run(wf.recover())
    assert wf.get_state(mid)["briefed"] is True and wf.get_state(mid)["finishing"] is False
    assert wf.get_state(mid2)["intro_started"] is False
    with SessionLocal() as s:
        assert s.get(Meeting, sid).status == "scheduled"


def test_stale_answer_is_ignored():
    mid, a, b = _make_live("review")
    with SessionLocal() as s:
        t1 = Task(intern_id=a, title="One", review_meeting_id=mid); t2 = Task(intern_id=b, title="Two", review_meeting_id=mid)
        s.add_all([t1, t2]); s.commit(); ids = [t1.id, t2.id]
    wf.upd_state(mid, queue=ids, idx=0, awaiting=True)
    asyncio.run(wf.apply_answer(mid, ids[1], "done", "late duplicate", None))   # not the current task
    with SessionLocal() as s:
        assert s.get(Task, ids[1]).status == "assigned"


def test_reschedule_only_when_scheduled(fresh):
    a, b = seed()
    async def run():
        mid = await wf.create_meeting("kickoff", "K", utcnow() + dt.timedelta(days=2), [a], notify=False)
        new = utcnow() + dt.timedelta(days=3)
        await wf.reschedule_meeting(mid, new, "K2", notify=False)
        with SessionLocal() as s:
            m = s.get(Meeting, mid); assert m.title == "K2" and m.scheduled_at == new
            m.status = "live"; s.commit()
        with pytest.raises(ValueError):
            await wf.reschedule_meeting(mid, new, notify=False)
    asyncio.run(run())


def test_recall_webhook_url_has_trailing_slash(monkeypatch):
    sent = {}
    async def fake_req(method, path, **kw): sent.update(kw["json"]); return {"id": "b1"}
    monkeypatch.setattr(recall, "_req", fake_req)
    asyncio.run(recall.create_bot(5, "https://zoom.us/j/1"))
    url = sent["recording_config"]["realtime_endpoints"][0]["url"]
    assert "/webhooks/recall/?token=" in url and url.endswith("meeting_id=5")


def test_http_retry_backoff(monkeypatch):
    import httpx
    from app.services import http as h
    calls = {"n": 0}
    class FakeClient:
        def __init__(self, **k): pass
        async def __aenter__(self): return self
        async def __aexit__(self, *a): return False
        async def request(self, m, u, **kw):
            calls["n"] += 1
            return httpx.Response(503 if calls["n"] < 3 else 200, json={"ok": 1}, request=httpx.Request(m, u))
    async def nosleep(_): pass
    monkeypatch.setattr(h.httpx, "AsyncClient", FakeClient)
    monkeypatch.setattr(h.asyncio, "sleep", nosleep)
    r = asyncio.run(h.request("GET", "http://x"))
    assert r.status_code == 200 and calls["n"] == 3


def test_web_auth_login_and_csv():
    from fastapi.testclient import TestClient
    from app.main import app, settings as ms
    c = TestClient(app)
    assert c.get("/api/stats").status_code == 401
    assert c.get("/", follow_redirects=False).status_code == 303
    bad = c.post("/login", data={"username": "x", "password": "y"})
    assert bad.status_code == 401
    ok = c.post("/login", data={"username": ms.dashboard_user, "password": ms.dashboard_password}, follow_redirects=False)
    assert ok.status_code == 303 and c.get("/api/stats").status_code == 200
    seed()
    r = c.get("/api/export/tasks.csv")
    assert r.status_code == 200 and r.headers["content-type"].startswith("text/csv")
    # webhook: bad token rejected, good token accepted at both URL forms
    assert c.post("/webhooks/recall/?token=bad&meeting_id=1", json={}).status_code == 401
    assert c.post(f"/webhooks/recall/?token={ms.webhook_secret}&meeting_id=1", json={}).status_code == 200


# ---------------------------------------------------------------- more tests
def test_alembic_fresh_and_adopt_legacy(tmp_path):
    import sqlalchemy as sa
    from alembic import command
    from alembic.config import Config
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    def up(url):
        cfg = Config(os.path.join(root, "alembic.ini")); cfg.set_main_option("script_location", os.path.join(root, "migrations"))
        e = sa.create_engine(url)
        with e.begin() as c:
            cfg.attributes["connection"] = c; command.upgrade(cfg, "head")
        return e
    e1 = up(f"sqlite:///{tmp_path}/fresh.db")
    assert {"meetings", "tasks", "utterances", "interns", "reviews", "logs", "kv", "alembic_version"} <= set(sa.inspect(e1).get_table_names())
    e2 = sa.create_engine(f"sqlite:///{tmp_path}/legacy.db"); Base.metadata.create_all(e2)   # pre-Alembic DB
    e2 = up(f"sqlite:///{tmp_path}/legacy.db")
    with e2.connect() as c:
        assert c.execute(sa.text("select version_num from alembic_version")).scalar() == "0002"


def test_recall_signature_verification():
    import base64, hashlib, hmac, time
    secret = "whsec_" + base64.b64encode(b"k" * 24).decode()
    body = b'{"event":"bot.done"}'; ts = str(int(time.time())); mid = "msg_1"
    good = base64.b64encode(hmac.new(b"k" * 24, f"{mid}.{ts}.".encode() + body, hashlib.sha256).digest()).decode()
    h = {"webhook-id": mid, "webhook-timestamp": ts, "webhook-signature": f"v1,AAAA v1,{good}"}
    assert recall.verify_signature(secret, h, body)
    assert recall.verify_signature(secret, {k.replace("webhook", "svix"): v for k, v in h.items()}, body)
    assert not recall.verify_signature(secret, h, body + b" ")
    assert not recall.verify_signature("", h, body)
    old = dict(h, **{"webhook-timestamp": str(int(time.time()) - 5000)})
    assert not recall.verify_signature(secret, old, body)


def test_status_webhook_finishes_meeting(monkeypatch):
    mid, a, b = _make_live("kickoff")
    done = []
    async def fake_finish(m): done.append(m)
    monkeypatch.setattr(wf, "finish", fake_finish)
    asyncio.run(wf.on_bot_status("botX", "call_ended"))
    asyncio.run(wf.on_bot_status("unknown", "call_ended"))
    assert done == [mid]


def test_status_webhook_endpoint(monkeypatch):
    import base64, hashlib, hmac, json, time
    from fastapi.testclient import TestClient
    from app.main import app, settings as ms
    monkeypatch.setattr(ms, "recall_webhook_secret", "whsec_" + base64.b64encode(b"z" * 16).decode())
    seen = []
    async def fake_status(bot, code, sub=None): seen.append((bot, code))
    monkeypatch.setattr(wf, "on_bot_status", fake_status)
    body = json.dumps({"event": "bot.done", "data": {"data": {"code": "done", "sub_code": None}, "bot": {"id": "B1"}}}).encode()
    ts = str(int(time.time()))
    sig = base64.b64encode(hmac.new(b"z" * 16, f"m1.{ts}.".encode() + body, hashlib.sha256).digest()).decode()
    c = TestClient(app)
    hdr = {"webhook-id": "m1", "webhook-timestamp": ts, "webhook-signature": "v1," + sig}
    assert c.post("/webhooks/recall-status/", content=body, headers=hdr).status_code == 200
    assert c.post("/webhooks/recall-status/", content=body, headers={**hdr, "webhook-signature": "v1,AAAA"}).status_code == 401
    import time as t; t.sleep(0.2)
    assert seen == [("B1", "done")]


def test_meet_and_teams_create(monkeypatch):
    from app.services import meet, teams, http as h
    calls = []
    async def fake_req(method, url, **kw):
        import httpx
        calls.append((method, url, kw.get("json")))
        if "oauth2.googleapis.com" in url or "login.microsoftonline.com" in url:
            j = {"access_token": "t", "expires_in": 3600}
        elif "meet.googleapis.com" in url:
            j = {"name": "spaces/abc", "meetingUri": "https://meet.google.com/abc-defg-hij"}
        else:
            j = {"id": "TEAMSID", "joinWebUrl": "https://teams.microsoft.com/l/meetup-join/x"}
        return httpx.Response(200, json=j, request=httpx.Request(method, url))
    monkeypatch.setattr(h, "request", fake_req)
    for k, v in dict(google_client_id="i", google_client_secret="s", google_refresh_token="r", teams_tenant_id="t",
                     teams_client_id="i", teams_client_secret="s", teams_host_user="guid").items():
        monkeypatch.setattr(wf.settings, k, v)
    meet._tok.update(v=None, exp=0); teams._tok.update(v=None, exp=0)
    start = utcnow() + dt.timedelta(days=1)
    monkeypatch.setattr(wf.settings, "meeting_provider", "meet")
    assert asyncio.run(wf.provider.create_meeting("T", start, 60)) == ("https://meet.google.com/abc-defg-hij", "spaces/abc")
    assert any(c[2] == {"config": {"accessType": "OPEN"}} for c in calls)
    monkeypatch.setattr(wf.settings, "meeting_provider", "teams")
    url, eid = asyncio.run(wf.provider.create_meeting("T", start, 30))
    assert eid == "TEAMSID" and url.startswith("https://teams.microsoft.com")
    body = [c for c in calls if "onlineMeetings" in c[1]][0]
    assert body[1].endswith("/users/guid/onlineMeetings") and body[2]["subject"] == "T"
    monkeypatch.setattr(wf.settings, "meeting_provider", "manual")
    with pytest.raises(ValueError):
        asyncio.run(wf.provider.create_meeting("T", start, 30))


def test_zoom_join_token_endpoint(monkeypatch):
    from fastapi.testclient import TestClient
    from app.main import app, settings as ms
    from app.services import zoom
    mid, a, b = _make_live("kickoff")
    with SessionLocal() as s:
        s.get(Meeting, mid).zoom_id = "123"; s.commit()
    async def fake_tok(zid): return f"TOKEN-{zid}"
    monkeypatch.setattr(zoom, "local_recording_token", fake_tok)
    monkeypatch.setattr(ms, "meeting_provider", "zoom")
    c = TestClient(app)
    assert c.get(f"/zoom/join-token/?token=bad&meeting_id={mid}").status_code == 401
    r = c.get(f"/zoom/join-token/?token={ms.webhook_secret}&meeting_id={mid}")
    assert r.status_code == 200 and r.text == "TOKEN-123"


# ---------------------------------------------------------------- HTTP-level end-to-end simulation
def test_e2e_http_kickoff_review_next_review(fresh, monkeypatch):
    """Drives the real REST API + webhook endpoints + scheduler tick through a whole kickoff -> review -> next review cycle."""
    import httpx
    from app.main import app, make_session, settings as ms
    sent, spoken = fresh
    monkeypatch.setattr(ms, "meeting_provider", "manual")
    created = []
    async def fake_create_bot(mid, url): created.append(mid); return f"bot-{mid}"
    monkeypatch.setattr(recall, "create_bot", fake_create_bot)
    a, b = seed()

    async def settle():
        for _ in range(30):
            await asyncio.sleep(0)

    async def run():
        tr = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=tr, base_url="http://t", cookies={"itb_session": make_session("admin")}) as c:
            hook = lambda mid: f"/webhooks/recall/?token={ms.webhook_secret}&meeting_id={mid}"
            async def ev(mid, e, pid, name):
                assert (await c.post(hook(mid), json={"event": e, "data": {"data": {"participant": {"id": pid, "name": name}}}})).status_code == 200
                await settle()
            n = [0]
            async def say(mid, pid, name, text):
                n[0] += 1
                body = {"event": "transcript.data", "data": {"data": {"words": [{"text": w, "start_timestamp": {"relative": n[0] + i / 10}} for i, w in enumerate(text.split())],
                                                                    "participant": {"id": pid, "name": name}}}}
                assert (await c.post(hook(mid), json=body)).status_code == 200
                await settle()
            def move_to_now(mid):
                with SessionLocal() as s2:
                    s2.get(Meeting, mid).scheduled_at = utcnow() - dt.timedelta(minutes=1); s2.commit()

            # 1) mentor creates a kickoff via the API
            r = await c.post("/api/meetings", json={"type": "kickoff", "title": "Kick", "scheduled_at": (utcnow() + dt.timedelta(hours=2)).isoformat(),
                                                    "join_url": "https://meet.google.com/abc-defg-hij",
                                                    "tasks": [{"intern_id": a, "title": "Build API"}, {"intern_id": b, "title": "Write docs"}]})
            assert r.status_code == 200, r.text
            kid = r.json()["id"]
            assert sum(1 for to, sub in sent if "[Kickoff]" in sub) == 2          # invites went out
            # 2) bot joins at start time, interns join, bot briefs
            move_to_now(kid); await wf.tick(); await settle()
            assert created == [kid] and (await c.get(f"/api/meetings/{kid}")).json()["status"] == "live"
            await ev(kid, "participant_events.join", 1, "Asha Rao"); await ev(kid, "participant_events.join", 2, "Ben Lee")
            await wf.tick(); await settle()
            assert wf.get_state(kid)["briefed"] and any("Build API" in t for t in spoken)
            await say(kid, 1, "Asha Rao", "when is the deadline for this")            # Q&A is answered
            await settle(); assert len(spoken) >= 3
            # 3) interns leave -> bot leaves -> post-processing -> review meeting + emails
            await ev(kid, "participant_events.leave", 1, "Asha Rao"); await ev(kid, "participant_events.leave", 2, "Ben Lee")
            wf.upd_state(kid, empty_since=(utcnow() - dt.timedelta(minutes=5)).isoformat())
            await wf.tick(); await settle()
            km = (await c.get(f"/api/meetings/{kid}")).json()
            assert km["status"] == "processed", km
            rid = wf.get_state(kid)["review_meeting_id"]
            assert sum(1 for to, sub in sent if "Your tasks" in sub) == 2
            with SessionLocal() as s2:
                assert all(t.deadline and t.review_meeting_id == rid for t in s2.query(Task).all())
            # 4) review day: Asha done, Ben stuck
            with SessionLocal() as s2:
                s2.get(Meeting, rid).join_url = "https://meet.google.com/rev-iew-xyz"; s2.commit()
            move_to_now(rid); await wf.tick(); await settle()
            await ev(rid, "participant_events.join", 1, "Asha Rao"); await ev(rid, "participant_events.join", 2, "Ben Lee")
            await wf.tick(); await settle()
            assert wf.get_state(rid)["awaiting"] is True
            first = wf.get_state(rid)["current_intern"]
            who = {"Asha Rao": (1, "I finished it, it is complete"), "Ben Lee": (2, "not done yet, I am stuck")}
            for _ in range(2):
                name = wf.get_state(rid)["current_intern"]; pid, txt = who[name]
                await say(rid, pid, name, txt); await settle()
            await settle()
            with SessionLocal() as s2:
                st2 = {t.intern.name: t.status for t in s2.query(Task).all()}
            assert st2 == {"Asha Rao": "done", "Ben Lee": "not_done"}, st2
            # 5) wrap-up scheduled the next review for the open task, bot left, results emailed
            nxt = wf.get_state(rid).get("next_review_meeting_id")
            assert nxt, "next review should be scheduled because Ben's task is open"
            await wf.tick(); await settle()
            assert (await c.get(f"/api/meetings/{rid}")).json()["status"] == "processed"
            assert any("Review results" in sub for _, sub in sent) and any("Review summary" in sub for _, sub in sent)
            nm = (await c.get(f"/api/meetings/{nxt}")).json()
            assert [x["name"] for x in nm["attendees"]] == ["Ben Lee"]
            stats = (await c.get("/api/stats")).json()
            assert stats["done_tasks"] == 1 and stats["open_tasks"] == 1
    asyncio.run(run())


def test_google_and_zoom_oauth_flows(monkeypatch):
    import urllib.parse, httpx
    from fastapi.testclient import TestClient
    from app.main import app, make_session, settings as ms
    from app.db import kv_get
    from app.services import meet, zoom, http as h
    for k, v in dict(google_client_id="gid", google_client_secret="gsec", zoom_oauth_client_id="zid",
                     zoom_oauth_client_secret="zsec", public_base_url="https://bot.example.com", meeting_provider="meet").items():
        monkeypatch.setattr(ms, k, v)
    calls = []
    async def fake_req(method, url, **kw):
        calls.append((method, url, kw))
        if "oauth2.googleapis.com" in url:
            j = {"refresh_token": "GREFRESH", "access_token": "a", "expires_in": 3600}
        elif "zoom.us/oauth/token" in url:
            j = {"refresh_token": "ZREFRESH-" + str(len(calls)), "access_token": "zacc"}
        else:
            j = {"token": "JT123"}
        return httpx.Response(200, json=j, request=httpx.Request(method, url))
    monkeypatch.setattr(h, "request", fake_req)
    c = TestClient(app, follow_redirects=False)
    assert c.get("/oauth/google/start").status_code == 401                       # login required
    c.cookies.set("itb_session", make_session("admin"))
    r = c.get("/oauth/google/start"); assert r.status_code == 303
    q = urllib.parse.parse_qs(urllib.parse.urlparse(r.headers["location"]).query)
    assert q["access_type"] == ["offline"] and q["scope"] == ["https://www.googleapis.com/auth/meetings.space.created"]
    assert q["redirect_uri"] == ["https://bot.example.com/oauth/google/callback"]
    assert c.get("/oauth/google/callback?code=x&state=forged").status_code == 400
    assert c.get(f"/oauth/google/callback?code=abc&state={q['state'][0]}").status_code == 303
    assert kv_get("google_refresh_token") == "GREFRESH" and meet.configured()
    # zoom host authorization then token fetch uses the host's OAuth token and stores the rotated refresh token
    r = c.get("/oauth/zoom/start"); zq = urllib.parse.parse_qs(urllib.parse.urlparse(r.headers["location"]).query)
    assert c.get(f"/oauth/zoom/callback?code=zc&state={zq['state'][0]}").status_code == 303
    assert zoom.host_authorized()
    before = kv_get("zoom_refresh_token")
    assert asyncio.run(zoom.local_recording_token("999")) == "JT123"
    assert kv_get("zoom_refresh_token") != before                                 # rotated
    last = calls[-1]; assert last[2]["headers"]["Authorization"] == "Bearer zacc" and last[1].endswith("/meetings/999/jointoken/local_recording")
    assert any(x["url"] == "/oauth/google/start" for x in c.get("/api/health").json()["connections"])


def test_preflight_runs_and_reports(monkeypatch, capsys):
    from app import preflight
    for k in ("recall_api_key", "anthropic_api_key", "elevenlabs_api_key", "openai_api_key", "smtp_host"):
        monkeypatch.setattr(wf.settings, k, "")
    monkeypatch.setattr(wf.settings, "meeting_provider", "manual")
    rc = asyncio.run(preflight.main("x@y.com", False))
    out = capsys.readouterr().out
    assert "[SKIP] Recall.ai API key" in out and "Config sanity" in out and "[FAIL] Config sanity" in out and rc == 1
