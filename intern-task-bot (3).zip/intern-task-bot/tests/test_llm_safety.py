"""Fake-LLM-output tests for app/services/llm_safety.py (pure stdlib; runs without network or settings)."""
import importlib.util
import pathlib

_spec = importlib.util.spec_from_file_location(
    "llm_safety", pathlib.Path(__file__).resolve().parents[1] / "app" / "services" / "llm_safety.py")
ls = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(ls)

TODAY = "2026-10-28"


def test_parse_json_fenced_and_chatty():
    assert ls.parse_json('Sure!\n```json\n{"a": 1}\n```\nHope that helps') == {"a": 1}
    assert ls.parse_json('{"a": "}{"} trailing {x}') == {"a": "}{"}


def test_parse_json_garbage_raises():
    for bad in ["", "   ", "no json here", '{"a": ', None]:
        try:
            ls.parse_json(bad)
        except ValueError:
            continue
        except Exception as e:  # json.JSONDecodeError is a ValueError subclass
            raise AssertionError(e)
        raise AssertionError(f"should have raised for {bad!r}")


def test_clean_date_rejects_past_future_and_nonsense():
    assert ls.clean_date("2026-11-05", TODAY) == "2026-11-05"
    assert ls.clean_date("2026-10-28", TODAY) == "2026-10-28"
    assert ls.clean_date("2025-01-01", TODAY) is None      # past / hallucinated
    assert ls.clean_date("2031-01-01", TODAY) is None      # > 1 year
    assert ls.clean_date("2026-02-30", TODAY) is None      # impossible
    assert ls.clean_date("next friday", TODAY) is None
    assert ls.clean_date(None, TODAY) is None
    assert ls.clean_date(20261105, TODAY) is None


def test_clean_plan_filters_unknown_ids_emails_and_types():
    raw = {"tasks": [{"id": 1, "deadline": "2026-11-02", "notes": " x "},
                     {"id": "2", "deadline": "1999-01-01"},
                     {"id": 99, "deadline": "2026-11-02"},
                     {"id": 1, "deadline": "2026-11-03"}, "junk", {"id": None}],
           "new_tasks": [{"intern_email": "A@x.com", "title": "T", "deadline": "2026-11-09"},
                         {"intern_email": "ghost@x.com", "title": "T"},
                         {"intern_email": "a@x.com", "title": ""}],
           "review_date": "2026-11-10"}
    p = ls.clean_plan(raw, [1, 2], ["a@x.com"], TODAY)
    assert [t["id"] for t in p["tasks"]] == [1, 2]
    assert p["tasks"][0]["deadline"] == "2026-11-02" and p["tasks"][0]["notes"] == "x"
    assert p["tasks"][1]["deadline"] is None
    assert len(p["new_tasks"]) == 1 and p["new_tasks"][0]["intern_email"] == "a@x.com"
    assert p["review_date"] == "2026-11-10"


def test_clean_plan_wrong_shapes():
    for raw in [None, [], "str", {"tasks": "x", "new_tasks": 5, "review_date": []}]:
        p = ls.clean_plan(raw, [1], ["a@x.com"], TODAY)
        assert p == {"tasks": [], "new_tasks": [], "review_date": None}


def test_clean_status():
    ok = ls.clean_status({"status": "done", "notes": "Shipped", "new_deadline": "2020-01-01"}, TODAY, "raw")
    assert ok == {"status": "done", "notes": "Shipped", "new_deadline": None}
    assert ls.clean_status({"status": "finished"}, TODAY, "raw") is None
    assert ls.clean_status([], TODAY, "raw") is None
    assert ls.clean_status({"status": "partial"}, TODAY, "raw")["notes"] == "raw"


def test_login_limiter():
    spec = importlib.util.spec_from_file_location(
        "ratelimit", pathlib.Path(__file__).resolve().parents[1] / "app" / "ratelimit.py")
    rl = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(rl)
    lim = rl.LoginLimiter(3, 100)
    for i in range(3):
        assert not lim.blocked("ip", now=1000 + i)
        lim.fail("ip", now=1000 + i)
    assert lim.blocked("ip", now=1010)
    assert not lim.blocked("other", now=1010)
    assert not lim.blocked("ip", now=1200)      # window passed
    lim.fail("ip", now=1200); lim.success("ip")
    assert not lim.blocked("ip", now=1201)
