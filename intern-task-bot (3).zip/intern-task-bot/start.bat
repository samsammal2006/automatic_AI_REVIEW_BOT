@echo off
cd /d "%~dp0"
if not exist .env (
  copy /y .env.example .env >nul
  echo Created .env from .env.example
)
if not exist .venv\Scripts\python.exe (
  echo Creating Python environment, one time...
  py -3 -m venv .venv 2>nul || python -m venv .venv
)
call .venv\Scripts\activate.bat
pip install -q -r requirements.txt
python run.py
pause
