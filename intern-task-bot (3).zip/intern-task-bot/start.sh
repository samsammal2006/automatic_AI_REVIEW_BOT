#!/usr/bin/env bash
# Mac / Linux launcher:  ./start.sh
cd "$(dirname "$0")" || exit 1
[ -f .env ] || { cp .env.example .env; echo "Created .env from .env.example"; }
[ -d .venv ] || python3 -m venv .venv
. .venv/bin/activate
pip install -q -r requirements.txt
python run.py
